if (!window.jQuery) {
    document.write('<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>');
}

$(window).ready(function() {
    var chromeInternalUrl = "chrome-extension://",
        head = document.getElementsByTagName("head")[0],
        body = document.getElementsByTagName("body")[0];

    $.get(chromeInternalUrl + UXC_main_config.id_app + "/tmpl/tmpl_plugin.html", function(data) {
        var link = document.createElement("div");

        link.innerHTML = data;
        head.appendChild(link);
    });

    $.get(chromeInternalUrl + UXC_main_config.id_app + "/js/content/injected_modal.js", function(data) {
        var script = document.createElement("script");

        script.setAttribute("type", "text/javascript");
        script.innerHTML = data;

        if (body) {
            body.appendChild(script);
        } else {
            document.getElementsByTagName("html")[0].appendChild(script);
        }

        $.get(chromeInternalUrl + UXC_main_config.id_app + "/tmpl/tmpl.html", function(data) {
            var link = document.createElement("div");

            link.innerHTML = data;

            head.appendChild(link);
            UXC_initialization();
        });
    });
});
