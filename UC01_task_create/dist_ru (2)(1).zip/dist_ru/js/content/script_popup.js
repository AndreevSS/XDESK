var uxc_work = true;
var clearUXContainer = function() {
    $(".UXC_Plugins").removeClass("rec");
    $(".uxc_question").html("");
};

function renderPopup(config) {
    switch (config.statusRec) {
        case "rec":
            var button, event;
            var class_next_step = "";
            var uxc_timer = 5 - (Math.floor(new Date().getTime() / 1000) - config.time_click_next);

            if (uxc_timer > 0) {
                class_next_step = "disabled";

                setTimeout(function() {
                    if (localStorage.getItem("uxc_update_time") == "true") {
                        localStorage.setItem("uxc_update_time", "false");
                        setBackground("update_config_popup");
                    }
                }, uxc_timer * 1000);
            } else {
                class_next_step = "active";
            }

            if (uxc_work || !config.on_pause) {
                $(".UXC_Plugins").addClass("rec");

                if (config.mainPageSteps.length == config.activeStep) {
                    $(".uxc_panel_btn").html(
                        tmpl("UXC_tmpl_btn_pause_stop", {
                            extBtnNext: chrome.i18n.getMessage("extBtnNext"),
                            extPause: chrome.i18n.getMessage("extPause"),
                            extBtnFinish: chrome.i18n.getMessage("extBtnFinish"),
                            class_next_step: class_next_step
                        })
                    );

                    button = $(".uxc_btn_stop");
                    localStorage.setItem("uxc_update_time", "true");
                    event = "stopRec";
                } else {
                    $(".uxc_panel_btn").html(
                        tmpl("UXC_tmpl_btn_pause_next", {
                            extBtnNext: chrome.i18n.getMessage("extBtnNext"),
                            extPause: chrome.i18n.getMessage("extPause"),
                            class_next_step: class_next_step
                        })
                    );

                    button = $(".uxc_item_next");
                    localStorage.setItem("uxc_update_time", "true");
                    event = "nextStep";
                }

                $(".uxc_question").html(
                    $.parseHTML(
                        tmpl("uxc_all_question", {
                            extTaskNumber: chrome.i18n.getMessage("extTaskNumber"),
                            all_questions: config.mainPageSteps[config.activeStep - 1],
                            activeStep: config.activeStep,
                            allStep: config.mainPageSteps.steps.length
                        })
                    )
                );
            }

            $(".uxc_question").html(
                $.parseHTML(
                    tmpl("uxc_all_question", {
                        extTaskNumber: chrome.i18n.getMessage("extTaskNumber"),
                        all_questions: config.mainPageSteps[config.activeStep - 1],
                        activeStep: config.activeStep,
                        allStep: config.mainPageSteps.length
                    })
                )
            );

            $(".uxc_close").click(function() {
                uxc_work = false;

                $(".container_mic").hide();
                $(".uxc_question").html('<div class="uxc_item uxc_active_step"><div class="uxc_item_description">Вы прерываете выполнения теста, видео не сохранится, тест будет доступен снова в ЛК.</div></div>');

                $(".uxc_panel_btn").html(
                    tmpl("UXC_tmpl_forcedShutdown", {
                        extBtnYes: chrome.i18n.getMessage("extBtnYes"),
                        extBtnNo: chrome.i18n.getMessage("extBtnNo")
                    })
                );

                $(".UXC_tmpl_forcedShutdown_yes").click(function() {
                    setBackgroundNotConfig("forcedShutdown");
                });

                $(".UXC_tmpl_forcedShutdown_no").click(function() {
                    uxc_work = true;
                    setBackground("openPopup");
                    $(".container_mic").show();
                });
            });

            var obj_question = config.mainPageSteps[config.activeStep - 1];
                debugger
            switch (obj_question.stepType) {
                case "TEXT":
                    $(button).unbind();
                    $(button).click(function() {
                        if (!$(this).hasClass("disabled")) {
                            setBackground(event);
                        }
                    });

                    break;
                case "RATING":
                    $(button).unbind();

                    $(button).click(function() {
                        value = $("input:radio[name ='uxc_item_rating_radio_group']:checked").val();

                        if (!value || value <= 0) {
                            $("#block_error").text("Укажите значение");
                        } else {
                            $("#block_error").text("");

                            if (!$(this).hasClass("disabled")) {
                                setBackground(event, value);
                            }
                        }
                    });

                    $(".uxc_rating_btn_custom").click(function() {
                        var value_radio = $(this)
                            .children("input")
                            .val();

                        localStorage.setItem("activeStep", config.activeStep);
                        localStorage.setItem("uxc_text_rating", value_radio);

                        $(".uxc_rating_btn_custom.active").removeClass("active");
                        $(this).addClass("active");
                        $(this)
                            .children("input")
                            .prop("checked", true);

                        for (var i = 0; i < value_radio; i++) {
                            $(".uxc_rating_btn_custom:eq(" + i + ")").addClass("active");
                        }
                    });

                    if (localStorage.getItem("activeStep") == config.activeStep) {
                        if (localStorage.getItem("uxc_text_rating")) {
                            $("input:radio[name ='uxc_item_rating_radio_group']:eq(" + (Number(localStorage.getItem("uxc_text_rating")) - 1) + ")").prop("checked", true);

                            for (var i = 0; i < Number(localStorage.getItem("uxc_text_rating")); i++) {
                                $(".uxc_rating_btn_custom:eq(" + i + ")").addClass("active");
                            }
                        }
                    }

                    break;
                case "ANSWER":
                    $("#uxc_item_answer_textarea").on("change, keyup", function() {
                        localStorage.setItem("activeStep", config.activeStep);
                        localStorage.setItem("uxc_text_textarea", $("#uxc_item_answer_textarea").val());
                    });

                    $(button).unbind();

                    $(button).click(function() {
                        value = $("#uxc_item_answer_textarea").val();

                        if (!$(this).hasClass("disabled")) {
                            if (!value || value.length == 0) {
                                $("#block_error").text("Введите ответ");
                            } else {
                                $("#block_error").text("");

                                localStorage.setItem("uxc_text_textarea", "");

                                setBackground(event, value);
                            }
                        }
                    });

                    if (localStorage.getItem("activeStep") == config.activeStep) {
                        if (localStorage.getItem("uxc_text_textarea")) {
                            $("#uxc_item_answer_textarea").val(localStorage.getItem("uxc_text_textarea"));
                        }
                    }

                    break;
                case "RADIO":
                    $(".uxc_rating_btn_custom_input").click(function() {
                        var num_radio = $(this)
                            .children("input")
                            .data("num-radio");

                        $(".uxc_rating_btn_custom_input.active").removeClass("active");
                        $(this).addClass("active");
                        $(this)
                            .children("input")
                            .prop("checked", true);

                        localStorage.setItem("activeStep", config.activeStep);
                        localStorage.setItem("uxc_text_radio", num_radio);
                    });

                    $(button).unbind();

                    $(button).click(function() {
                        value = $("input:radio[name ='uxc_item_radio_group']:checked").val();

                        if (!value) {
                            $("#block_error").text("Укажите значение");
                        } else {
                            $("#block_error").text("");

                            if (!$(this).hasClass("disabled")) {
                                setBackground(event, value);
                            }
                        }
                    });

                    if (localStorage.getItem("activeStep") == config.activeStep) {
                        if (localStorage.getItem("uxc_text_radio")) {
                            var el = $("input:radio[data-num-radio =" + localStorage.getItem("uxc_text_radio") + "]");

                            $(el)
                                .parent("div")
                                .addClass("active");
                            $(el).prop("checked", true);
                        }
                    }

                    break;
                case "CHECKBOX":
                    $(".uxc_rating_btn_custom_input_checkbox").click(function() {
                        var array_checkbox = [];

                        if ($(this).children("input").prop("checked")) {
                            $(this)
                                .children("input")
                                .prop("checked", false);

                            $(this).removeClass("active");
                        } else {
                            $(this)
                                .children("input")
                                .prop("checked", true);
                            $(this).addClass("active");
                        }

                        $(".uxc_rating_btn_custom_input_checkbox input:checked").each(function() {
                            array_checkbox.push($(this).data("num-checkbox"));
                        });

                        localStorage.setItem("activeStep", config.activeStep);
                        localStorage.setItem("uxc_text_checkbox", JSON.stringify(array_checkbox));
                    });

                    $(button).unbind();

                    $(button).click(function() {
                        value = $("input:checkbox[name ='uxc_item_checkbox']:checked")
                            .map(function() {
                                return $(this).val();
                            })
                            .get();

                        if (!value || value.length == 0) {
                            $("#block_error").text("Укажите значение");
                        } else {
                            $("#block_error").text("");

                            if (!$(this).hasClass("disabled")) {
                                setBackground(event, value);
                            }
                        }
                    });

                    if (localStorage.getItem("activeStep") == config.activeStep) {
                        if (localStorage.getItem("uxc_text_checkbox")) {
                            var array_checkbox = JSON.parse(localStorage.getItem("uxc_text_checkbox"));

                            for (var i in array_checkbox) {
                                var el = $("input:checkbox[data-num-checkbox =" + array_checkbox[i] + "]");

                                $(el)
                                    .parent("div")
                                    .addClass("active");
                                $(el).prop("checked", true);
                            }
                        }
                    }

                    break;
            }

            $(".uxc_item_pause").click(function() {
                uxc_work = false;
                setBackground("pauseRec", null, {
                    "eventPage": "pauseRec",
                    "statusRec":  "pause",
                    "config": { "statusRec": "pause" }});
            });

            break;
        case "pause":
            clearUXContainer();

            $(".uxc_panel_btn").html(tmpl("UXC_tmpl_btn_resume", { extBtnContinue: chrome.i18n.getMessage("extBtnContinue") }));

            $(".uxc_item_resume").click(function() {
                uxc_work = true;
                var objForInjected = {
                    "eventPage": "continueRec",
                    "statusRec":  "continue",
                    "config": { "statusRec": "rec" }};
                setBackground("resumeRec", null, objForInjected);
            });

            break;
        case "selectDesktop":
            clearUXContainer();

            $(".uxc_panel_btn").html(tmpl("UXC_tmpl_select_desktop", { extRequest: chrome.i18n.getMessage("extRequest")}));

            $(".uxc_close").click(function() {
                setBackgroundNotConfig("forcedShutdown");
            });

            break;
        case "default":
            clearUXContainer();

            $(".uxc_panel_btn").html(tmpl("UXC_tmpl_btn_start", { extTaskText: chrome.i18n.getMessage("extTaskText") }));

            break;
        case "show_requirements":
            clearUXContainer();

            $(".uxc_panel_btn").html(tmpl("UXC_tmpl_select_desktop", { extRequest: chrome.i18n.getMessage("extRequest") }));

            $(".uxc_close").click(function() {
                setBackgroundNotConfig("forcedShutdown");
            });

            break;
    }
}

//Отправка в DOM (injected_modal.js)
function setDom(code, tabId) {
    chrome.tabs.executeScript(tabId, { code: code });
}

//Отправка в Background.js
function setBackground(eventPage, answerValue, objForInjected) {
    chrome.runtime.sendMessage({ eventPage: eventPage, answerValue: answerValue }, function(obj) {
        console.log('Popup OBJ. Really?!');
        console.log(obj);
        if (obj.config) {
            renderPopup(obj.config);
        }

        if (objForInjected) {
            chrome.tabs.query({ currentWindow: true, active: true}, function (tabs){
                var activeTab = tabs[0];
                var statusRec = objForInjected.config.statusRec;
                objForInjected.config = obj.config;
                objForInjected.config.statusRec = statusRec;
                chrome.tabs.sendMessage(activeTab.id, objForInjected);
            });
        }

        return obj;
    });

    
}



function setBackgroundNotConfig(eventPage, answerValue) {
    chrome.runtime.sendMessage({ eventPage: eventPage, answerValue: answerValue }, function(obj) {});
}

setBackground("openPopupApp");

clearUXContainer();
$(".uxc_panel_btn").html(tmpl("UXC_tmpl_btn_start", { extTaskText: chrome.i18n.getMessage("extTaskText") }));

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.eventPage == "UXC_mic_progress") {
        $("#UXC_mic_progress").css({ height: request.progress + "%" });
    }

    if (request.eventPage == "UXC_mic_fail") {
        $("#micro_block_error").text("На вашем микрофоне отсутствует сигнал. Говорите громче или прибавьте чувствительность микрофона");
    }

    if (request.eventPage == "UXC_mic_fixed") {
        $("#micro_block_error").text("");
    }

    if (request.eventPage == "update_popup") {
        renderPopup(request.config);
    }
});
