var constraints = { audio: true };
var mainTabId;
var tabId;
var timerId;

function checkMicrophone() {
    var modalGood = document.getElementById("uxc_main_modal_good"),
        modalBad = document.getElementById("uxc_main_modal_bad"),
        modalNotFound = document.getElementById("uxc_main_modal_not_found");

    var textTranslationsMap = {
        "extGrantMic": "extGrantMic",
        "extGrantMic2": "extGrantMic2",
        "extGrantMic3": "extGrantMic3",
        "extGrantMic4": "extGrantMic4",
        "extGrantMic5": "extGrantMic5",
        "extGrantMic6": "extGrantMic6",
        "extGrantMic61": "extGrantMic61",
        "extGrantMic62": "@@extension_id",
        "extGrantMic7": "extGrantMic7",
        "extGrantMic8": "extGrantMic8",
        "extGrantMic9": "extGrantMic9"
    };

    var mapTranslation = function(map) {
        for(key in map) {
            document.getElementById(key).innerHTML = chrome.i18n.getMessage(map[key]);
        }
    };
    mapTranslation(textTranslationsMap);


    navigator.getUserMedia({ audio: true },
        function(stream) {
            modalBad.style.display = "none";
            modalGood.style.display = "block";

            clearInterval(timerId);

            chrome.runtime.sendMessage({
                eventPage: "microOK",
                tabId: tabId,
                mainTabId: mainTabId
            });
        },
        function(error) {
            console.error(error);

            modalGood.style.display = "none";

            if (error.name == "DevicesNotFoundError") {
                modalNotFound.style.display = "block";
            } else {
                modalBad.style.display = "block";
            }
        }
    );
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log(request.message);

    if (request.message.tabId != null) {
        mainTabId = request.message.mainTabId;
        tabId = request.message.tabId;
    }

    timerId = setInterval(checkMicrophone, 1000);
});

chrome.runtime.sendMessage({ eventPage: "readyForCheckMic" });
