var UXC_requirements = { status: false, text: "" };
var uxc_work = true;
var tester_role = null;

var clearUXContainer = function() {
    $(".uxc_info_text").hide();
    $(".UXC_Plugins").removeClass("rec");
    $(".uxc_question").html("");
    $(".uxc_panel_btn").html("");
};

function UXC_initialization() {
    var uxc_element;
    var i = 0;
    setBackground("openPopup");

    chrome.runtime.sendMessage(chrome.i18n.getMessage("@@extension_id"), { eventPage: "grabRequirements" }, function(response) {
        if (response && response.config && response.config.requirements) {

            if (document.querySelectorAll(".UXC_Plugins").length === 0) {
                $("body").append(tmpl("uxc_main_window_plugin", {}));
            }
            $(".UXC_Plugins").removeClass("rec");
            $(".uxc_question").html("");

            UXC_open_modal(response.config.requirements, "", chrome.i18n.getMessage("extContinue"), "uxc_btn_play uxc_green", "white_one");

            clearUXContainer();

            $(".uxc_btn_play").click(function() {
                console.log("rec");

                chrome.runtime.sendMessage({ eventPage: "update_config_status_rec" });

                if (document.getElementById("uxc_main_modal")) {
                    document.getElementsByTagName("html")[0].removeChild(document.getElementById("uxc_main_modal"));
                }
            });
        }
    });

    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        if (request.eventPage == "update") {
            renderPopup(request.config);

            return;
        }

        if (request.eventPage == "audioStartError") {
            UXC_open_modal(
                chrome.i18n.getMessage("extRetryRecord"),
                function() {
                    chrome.runtime.sendMessage({ eventPage: "forcedShutdown" });
                    location.reload();
                },
                chrome.i18n.getMessage("extStartAgain"), "uxc_btn_play uxc_green"
            );

            $(".UXC_Plugins").remove();
            $("#uxc_main_modal.white");

            return;
        }

        if (request.eventPage == "pauseRec") {
            console.log(request);
            uxc_work = false;
            setBackground("pauseRec");
            renderPopup(request.config);

            return;
        }

        if (request.eventPage == "continueRec") {
            console.log(request);
            uxc_work = true;
            UXC_main_config.statusRec = "rec";
            renderPopup(request.config);

            return;
        }

        if (request.eventPage == "UXC_mic_progress") {
            $("#UXC_mic_progress").css({ height: request.progress + "%" });

            return;
        }

        if (request.eventPage == "UXC_mic_fail") {
            $("#micro_block_error").text(chrome.i18n.getMessage("extMicFail"));

            return;
        }

        if (request.eventPage == "UXC_mic_fixed") {
            $("#micro_block_error").text("");

            return;
        }

        if (request.eventPage == "microNotOKinTest") {
            UXC_open_modal(
                chrome.i18n.getMessage("extMicNotOk"),
                function() {
                    chrome.runtime.sendMessage({ eventPage: "forcedShutdown" });
                    location.reload();
                },
                chrome.i18n.getMessage("extStartAgain"),
                "uxc_btn_play uxc_green"
            );

            $(".UXC_Plugins").remove();

            return;
        }

        if (request.eventPage == "progress") {
            $(".uxc_text_modal").text(chrome.i18n.getMessage("extLoading"));
            $("#uxc_progress_wrap").removeAttr("style");
            $("#uxc_progress").width(request.progress + "%");
            $("#_uxcrowd_send_btn").hide();
            $("#_uxcrowd_send_btn_fail").hide();

            return;
        }

        if (request.eventPage == "show_info") {
            tester_role = request.tester_role;
            UXC_next(2);

            return;
        }

        if (request.eventPage == "show_select_window") {
            UXC_open_modal(
                chrome.i18n.getMessage("extSelectScreen"),
                [
                    {
                        text_btn: chrome.i18n.getMessage("extSelectAgain"),
                        class_btn: "uxc_green",
                        function_btn: function() {
                            selectTab();
                        }
                    },
                    {
                        text_btn: chrome.i18n.getMessage("extStopRecord"),
                        class_btn: "uxc_ml_15",
                        function_btn: function() {
                            forcedShutdown();
                        }
                    }
                ],
                "",
                "",
                "two_btn"
            );

            return;
        }

        if (request.eventPage == "requirements") {
            UXC_requirements.status = true;
            UXC_requirements.text = request.requirements;
            UXC_next(2);

            return;
        }

        if (request.eventPage == "no_requirements") {
            UXC_requirements.status = false;
            UXC_next(2);

            return;
        }

        if (request.eventPage == "finalModal") {
            UXC_next(3);

            return;
        }

        if (request.eventPage == "hideSpinner") {
            $("#uxc_instruction_block").hide();

            return;
        }

        if (request.eventPage == "reloadPageRec") {
            UXC_requirements.status = false;
            location.reload();

            return;
        }

        if (request.eventPage == "closeRecTab") {
            UXC_open_modal(
                chrome.i18n.getMessage("extClosedTestingPage"),
                [
                    {
                        text_btn: chrome.i18n.getMessage("extOpenAgain"),
                        class_btn: "uxc_green",
                        function_btn: function() {
                            openCloseTab();
                        }
                    },
                    {
                        text_btn: chrome.i18n.getMessage("extContinueTest"),
                        class_btn: "uxc_green",
                        function_btn: function() {
                            recCloseTab();
                        }
                    },
                    {
                        text_btn: chrome.i18n.getMessage("extStopRecord"),
                        class_btn: "uxc_ml_15",
                        function_btn: function() {
                            forcedShutdown();
                        }
                    }
                ],
                chrome.i18n.getMessage("extCancel"),
                "uxc_green",
                "three_btn"
            );

            return;
        }

        if (request.eventPage == "update_first") {
            if (request.config.statusRec != "audioStartError") {
                if ($("#uxc_main_modal").length == 1) {
                    return;
                }

                UXC_open_modal(request.config.requirements, "", chrome.i18n.getMessage("extContinue"), "uxc_btn_play uxc_green", "white_one");

                clearUXContainer();

                $(".uxc_btn_play").click(function() {
                    console.log("rec");

                    chrome.runtime.sendMessage({ eventPage: "update_config_status_rec" });

                    if (document.getElementById("uxc_main_modal")) {
                        document.getElementsByTagName("html")[0].removeChild(document.getElementById("uxc_main_modal"));
                    }
                });
            }

            return;
        }

        if (request.eventPage == "closeAfterTab") {
            UXC_open_modal(
                chrome.i18n.getMessage("extClosedAllPages"),
                function() {
                    chrome.runtime.sendMessage({ eventPage: "openCloseTab" });
                    document.getElementsByTagName("html")[0].removeChild(document.getElementById("uxc_main_modal"));
                },
                chrome.i18n.getMessage("extOpenAgain"),
                "uxc_green",
                ""
            );

            return;
        }

        if (request.eventPage == "endRec") {
            var congrat_text = chrome.i18n.getMessage("extThanksForVideo");

            if (tester_role == "ROLE_SIDE_TESTER") {
                congrat_text = chrome.i18n.getMessage("extThanksGoodWork");
                UXC_open_modal(congrat_text, null, "", "", "no_btn");

                $(".uxc_close_modal").hide();

                window.onbeforeunload = null;
                chrome.runtime.sendMessage({ eventPage: "reloadApp" });
            } else {
                UXC_open_modal(
                    congrat_text,
                    function() {
                        window.onbeforeunload = null;
                        chrome.runtime.sendMessage({ eventPage: "reloadApp" });
                        location.reload();
                    },
                    "OK",
                    "uxc_green"
                );
            }

            return;
        }

        if (request.eventPage == "sendFail") {
            $("#uxc_progress_wrap").hide();
            $(".UXC_Plugins").remove();

            UXC_open_modal(request.text, function() {}, chrome.i18n.getMessage("extSendAgain"), "uxc_green", "sendFail");

            return;
        }

        if (request.firstStart == true) {
            UXC_open_modal(
                chrome.i18n.getMessage("extOkNowActivate"),
                function() {
                    chrome.runtime.sendMessage({ eventPage: "firstStart" });
                    document.getElementsByTagName("html")[0].removeChild(document.getElementById("uxc_main_modal"));
                },
                chrome.i18n.getMessage("extOkNext"),
                "uxc_green",
                "",
                "reloadAppFirst"
            );

            return;
        }

        if (request.firstEnd == true) {
            UXC_open_modal(
                chrome.i18n.getMessage("extThanksActivated"),
                function() {
                    chrome.runtime.sendMessage({ eventPage: "firstEnd" });
                    document.getElementsByTagName("html")[0].removeChild(document.getElementById("uxc_main_modal"));
                    location.reload();
                },
                chrome.i18n.getMessage("extGoToTest"),
                "uxc_green",
                "",
                "reloadApp"
            );

            return;
        }

        if (request.eventPage == "openBeforeFinalModal") {
            UXC_open_modal(chrome.i18n.getMessage("extVideoRecorded"), "no_btn");

            return;
        }

        if (request.statusRecEl == "false") {
            UXC_open_modal(
                chrome.i18n.getMessage("extSorryTestNotAvailable"),
                function() {
                    chrome.runtime.sendMessage({ eventPage: "reloadApp" });
                    document.getElementsByTagName("html")[0].removeChild(document.getElementById("uxc_main_modal"));
                    location.reload();
                },
                chrome.i18n.getMessage("extClose"),
                ""
            );

            return;
        }

        if (request.eventPage == "openFinalModal") {
            var text = chrome.i18n.getMessage("extVideoSaved");

            console.log("uxc_work");

            uxc_work = false;

            if (tester_role == "ROLE_SIDE_TESTER") {
                text = chrome.i18n.getMessage("extTestReady");
            }

            UXC_open_modal(text, function() {}, chrome.i18n.getMessage("extSend"), "uxc_green", "finished");

            return;
        }
        // предупреждение после попытки закрыть главную вкладку ("Прервать тестирование?")
        if (request.eventPage == "interrupt") {
            UXC_open_modal(
                chrome.i18n.getMessage("interrupt_text"),
                [
                    {
                        text_btn: chrome.i18n.getMessage("extContinue"),
                        class_btn: "uxc_green",
                        function_btn: function() {
                            chrome.runtime.sendMessage({ eventPage: "continue_after_interrupt" });
                            location.reload();
                        }
                    },
                    {
                        text_btn: chrome.i18n.getMessage("extStopRecord"),
                        class_btn: "uxc_ml_15",
                        function_btn: function() {
                            forcedShutdown();
                        }
                    }
                ],
                "",
                "",
                "two_btn"
            );

            return;
        }

        //Ошибка сервера
        if (request.eventPage == "error") {
            var error_text = chrome.i18n.getMessage("serverError");
            UXC_open_modal(error_text, null, "", "", "no_btn");
            return;
        }
    });
}

function openCloseTab() {
    chrome.runtime.sendMessage({ eventPage: "openCloseTab" });
    document.getElementsByTagName("html")[0].removeChild(document.getElementById("uxc_main_modal"));
}

function reloadApp() {
    chrome.runtime.sendMessage({ eventPage: "reloadApp" });
    location.reload();
}

function forcedShutdown() {
    chrome.runtime.sendMessage({ eventPage: "forcedShutdown" });
    location.reload();
}

function recCloseTab() {
    chrome.runtime.sendMessage({ eventPage: "recCloseTab" });
    document.getElementsByTagName("html")[0].removeChild(document.getElementById("uxc_main_modal"));
}

function selectTab() {
    chrome.runtime.sendMessage({ eventPage: "selectTab" });
    document.getElementsByTagName("html")[0].removeChild(document.getElementById("uxc_main_modal"));
}

function updateStatusMic() {
    document.getElementsByTagName("html")[0].removeChild(document.getElementById("uxc_main_modal"));
    location.reload();
}

function UXC_next(num) {
    switch (num) {
        case 1:
            var text;

            if (tester_role == "ROLE_SIDE_TESTER") {
                text = chrome.i18n.getMessage("extMessage001");
            } else {
                text = chrome.i18n.getMessage("extIntruductionText");
            }

            UXC_open_modal(
                text,
                function() {
                    UXC_next(2);
                },
                chrome.i18n.getMessage("extMessage002"),
                "uxc_green"
            );

            break;

        case 2:
            var text = chrome.i18n.getMessage("extMessage003");

            UXC_open_modal(text, "", chrome.i18n.getMessage("extConfirm"), "uxc_btn_play uxc_green");

            $(".uxc_btn_play").click(function() {
                $(this).hide();
                $("#uxc_text_for_instruction").hide();
                $(".uxc_text_modal").append(chrome.i18n.getMessage("extMessage004"));
                chrome.runtime.sendMessage({ eventPage: "startRec" });
            });

            break;

        case 3:
            var text = chrome.i18n.getMessage("extMessage005");

            UXC_open_modal(text, "", chrome.i18n.getMessage("extLetsGo"), "uxc_btn_play uxc_green");

            $(".uxc_btn_play").click(function() {
                chrome.runtime.sendMessage({ eventPage: "secondStart" });
                $(".uxc_content_modal").hide();
            });

            break;

        case 4:
            UXC_open_modal(UXC_requirements.text, "", chrome.i18n.getMessage("extMessage006"), "uxc_btn_play uxc_green");

            $(".uxc_btn_play").click(function() {
                document.getElementsByTagName("html")[0].removeChild(document.getElementById("uxc_main_modal"));
                chrome.runtime.sendMessage({ eventPage: "startRec" });
            });

            break;
    }
}

var UXC_open_modal = (window.UXC_open_modal = function UXC_open_modal(text, func, text_btn, uxc_class, type, api, objThree) {
    if (document.getElementById("uxc_main_modal")) {
        document.getElementsByTagName("html")[0].removeChild(document.getElementById("uxc_main_modal"));
    }

    if (type == "sendFail") {
        var uxc_element = document.createElement("div");

        uxc_element.id = "uxc_main_modal";
        uxc_element.innerHTML = tmpl("UXC_tmpl_video_send_fail", {
            text: text,
            _uxcrowd_send_btn_fail: chrome.i18n.getMessage("_uxcrowd_send_btn_fail")
        });

        document.getElementsByTagName("html")[0].appendChild(uxc_element);
        document.getElementById("_uxcrowd_send_btn_fail").addEventListener("click", function() {
            $("#uxc_progress_wrap").removeAttr("style");
            chrome.runtime.sendMessage({ eventPage: "autoAndSaveAndSendVideo" }, function(obj) {});
        });
        addCloseBtn(api);

        return;
    }

    if (type == "finished") {
        var uxc_element = document.createElement("div");

        uxc_element.id = "uxc_main_modal";
        uxc_element.innerHTML = tmpl("UXC_tmpl_video_send", {
            text: text,
            _uxcrowd_send_btn: chrome.i18n.getMessage("_uxcrowd_send_btn")
        });

        document.getElementsByTagName("html")[0].appendChild(uxc_element);
        document.getElementById("_uxcrowd_send_btn").addEventListener("click", function() {
            $("#uxc_progress_wrap").removeAttr("style");
            chrome.runtime.sendMessage({ eventPage: "saveAndSendVideo" }, function(obj) {});
        });
        addCloseBtn(api);

        return;
    }

    if (type == "white_one") {
        var uxc_element = document.createElement("div");
        var uxc_html_element = tmpl("UXC_tmpl_modal_white", {
            text: text,
            textBtn: text_btn,
            introduction: chrome.i18n.getMessage("introduction"),
            uxc_class: uxc_class
        });

        uxc_element.id = "uxc_main_modal";
        uxc_element.innerHTML = uxc_html_element;

        if ($("#uxc_main_modal").length == 1) {
            return;
        }

        document.getElementsByTagName("html")[0].appendChild(uxc_element);
        $("#uxc_main_modal").addClass("white");

        uxc_element.getElementsByClassName("uxc_btn_modal")[0].addEventListener("click", function() {
            $("#uxc_main_modal").removeClass("white");
            document.getElementsByTagName("html")[0].removeChild(document.getElementById("uxc_main_modal"));
            chrome.runtime.sendMessage({ eventPage: "update_config" });
        });
        addCloseBtn(api);

        return;
    }

    if (type == "info_modal") {
        var obj_modal = func[0];
        var all_element_info = '<div class="' + obj_modal.mainClass + '">';
        var arrayBtn = obj_modal.buttons;
        var uxc_element = document.createElement("div");

        for (var obj_element_info in obj_modal.info) {
            console.log(obj_element_info);

            all_element_info += '<div class="obj_element_info">' + '<div class="obj_element_info_img ' +
                obj_modal.info[obj_element_info].class + '" style="background:' +
                obj_modal.info[obj_element_info].img + '"></div>' + '<div class="obj_element_info_text" style="margin-bottom:' +
                obj_modal.info[obj_element_info].mb + '">' + obj_modal.info[obj_element_info].text + "</div>" + "</div>";
        }

        all_element_info += "</div>";
        uxc_element.id = "uxc_main_modal";
        uxc_element.innerHTML = tmpl("UXC_tmpl_modal_custom", {
            all_element_info: all_element_info,
            uxc_class_btn_one: arrayBtn[0].class_btn,
            text_one_btn: arrayBtn[0].text_btn,
            uxc_class_btn_two: arrayBtn[1].class_btn,
            text_two_btn: arrayBtn[1].text_btn
        });

        document.getElementsByTagName("html")[0].appendChild(uxc_element);
        document.getElementsByTagName("html")[0].appendChild(uxc_element);

        document.getElementById("_uxc_one_btn").addEventListener("click", function() {
            obj_modal.buttons[0].function_btn();
        });
        document.getElementById("_uxc_two_btn").addEventListener("click", function() {
            obj_modal.buttons[1].function_btn();
        });

        addCloseBtn(api);

        return;
    }

    if (type == "three_btn") {
        var arrayBtn = func;
        var uxc_element = document.createElement("div");

        console.log("arrayBtn", arrayBtn);

        uxc_element.id = "uxc_main_modal";
        uxc_element.innerHTML = tmpl("UXC_tmpl_modal_three", {
            text: text,
            uxc_class_btn_one: arrayBtn[0].class_btn,
            text_one_btn: arrayBtn[0].text_btn,
            uxc_class_btn_two: arrayBtn[1].class_btn,
            text_two_btn: arrayBtn[1].text_btn,
            uxc_class_btn_three: arrayBtn[2].class_btn,
            text_three_btn: arrayBtn[2].text_btn
        });

        document.getElementsByTagName("html")[0].appendChild(uxc_element);

        document.getElementById("_uxc_one_btn").addEventListener("click", function() {
            arrayBtn[0].function_btn();
        });
        document.getElementById("_uxc_two_btn").addEventListener("click", function() {
            arrayBtn[1].function_btn();
        });
        document.getElementById("_uxc_three_btn").addEventListener("click", function() {
            arrayBtn[2].function_btn();
        });

        addCloseBtn(api);

        return;
    }

    if (type == "two_btn") {
        var arrayBtn = func;
        var uxc_element = document.createElement("div");

        console.log("arrayBtn", arrayBtn);

        uxc_element.id = "uxc_main_modal";
        uxc_element.innerHTML = tmpl("UXC_tmpl_modal_two", {
            text: text,
            uxc_class_btn_one: arrayBtn[0].class_btn,
            text_one_btn: arrayBtn[0].text_btn,
            uxc_class_btn_two: arrayBtn[1].class_btn,
            text_two_btn: arrayBtn[1].text_btn
        });

        document.getElementsByTagName("html")[0].appendChild(uxc_element);

        document.getElementById("_uxc_one_btn").addEventListener("click", function() {
            arrayBtn[0].function_btn();
        });
        document.getElementById("_uxc_two_btn").addEventListener("click", function() {
            arrayBtn[1].function_btn();
        });

        addCloseBtn(api);

        return;
    }

    if (type == "no_btn") {
        var uxc_element = document.createElement("div");

        uxc_element.id = "uxc_main_modal";
        uxc_element.innerHTML = tmpl("UXC_tmpl_modal_no_btn", {
            text: text
        });

        document.getElementsByTagName("html")[0].appendChild(uxc_element);
        addCloseBtn(api);
    } else {
        var uxc_element = document.createElement("div");

        uxc_element.id = "uxc_main_modal";
        uxc_element.innerHTML = tmpl("UXC_tmpl_modal", {
            text: text,
            funcModal: func,
            textBtn: text_btn,
            uxc_class: uxc_class
        });

        document.getElementsByTagName("html")[0].appendChild(uxc_element);

        uxc_element.getElementsByClassName("uxc_btn_modal")[0].addEventListener("click", function() {
            if (func != "") {
                func();
            }
        });

        addCloseBtn(api);
    }
});

function addCloseBtn(api) {
    if ($(".uxc_close_modal").length <= 0) {
        $("#uxc_main_modal").append('<div class="uxc_close_modal"></div>');

        $(".uxc_close_modal").click(function() {
            if (api) {
                chrome.runtime.sendMessage({ eventPage: api });
                location.reload();
            } else {
                chrome.runtime.sendMessage({ eventPage: "forcedShutdown" });
                location.reload();
            }
        });
    }
}

//Шаблонизатор http://javascript.ru/unsorted/templating 03.08.16
(function() {
    var cache = {};
    this.tmpl = function tmpl(str, data) {
        var fn = !/\W/.test(str)
            ? (cache[str] = cache[str] || tmpl(document.getElementById(str).innerHTML))
            : new Function(
                  "obj",
                  "var p=[],print=function(){p.push.apply(p,arguments);};" +
                      "with(obj){p.push('" +
                      str
                          .replace(/[\r\t\n]/g, " ")
                          .split("<%")
                          .join("\t")
                          .replace(/((^|%>)[^\t]*)'/g, "$1\r")
                          .replace(/\t=(.*?)%>/g, "',$1,'")
                          .split("\t")
                          .join("');")
                          .split("%>")
                          .join("p.push('")
                          .split("\r")
                          .join("\\'") +
                      "');}return p.join('');"
              );
        return data ? fn(data) : fn;
    };
})();

function renderPopup(config) {

    var clearQuestionContainer = function() {
        $(".UXC_Plugins").removeClass("rec");
        $(".uxc_question").html("");
    }; 

    if (document.querySelectorAll(".UXC_Plugins").length === 0) {
        console.log(">>>>>>> Before adding:");
        console.log('script didn\'t find the popup');
        console.log(document.querySelectorAll(".UXC_Plugins"));
        $("body").append(tmpl("uxc_main_window_plugin", {}));
        clearQuestionContainer();
        console.log(">>>>>>> After adding:");
        console.log(document.querySelectorAll(".UXC_Plugins"));
    }
    // console.log(config);

    // console.log(chrome.i18n.getMessage("extMessage008"), config);

    switch (config.statusRec) {
        case "audioStartError":
            UXC_open_modal(
                chrome.i18n.getMessage("extMessage007"),
                function() {
                    chrome.runtime.sendMessage({ eventPage: "forcedShutdown" });
                    location.reload();
                },
                chrome.i18n.getMessage("extMessage009"),
                "uxc_btn_play uxc_green"
            );

            $(".UXC_Plugins").remove();
            $("#uxc_main_modal.white");

            break;

        case "rec":
            var button, event;
            var class_next_step = "";
            var uxc_timer = 5 - (Math.floor(new Date().getTime() / 1000) - config.time_click_next);

            if (uxc_timer > 0) {
                class_next_step = "disabled";

                console.log(uxc_timer);

                setTimeout(function() {
                    console.log("");

                    if (localStorage.getItem("uxc_update_time") == "true") {
                        localStorage.setItem("uxc_update_time", "false");

                        console.log("update");

                        chrome.runtime.sendMessage({ eventPage: "update_config" });
                    }
                }, uxc_timer * 1000);

            } else {

                class_next_step = "active";

            } if (uxc_work || !config.on_pause) {
                $(".UXC_Plugins").addClass("rec");

                if (config.mainPageSteps.length == config.activeStep) {
                    $(".uxc_panel_btn").html(
                        tmpl("UXC_tmpl_btn_pause_stop", {
                            extPause: chrome.i18n.getMessage("extPause"),
                            extBtnFinish: chrome.i18n.getMessage("extBtnFinish"),
                            class_next_step: class_next_step
                        })
                    );

                    button = $(".uxc_btn_stop");
                    localStorage.setItem("uxc_update_time", "true");
                    event = "stopRec";
                } else {
                    $(".uxc_panel_btn").html(
                        tmpl("UXC_tmpl_btn_pause_next", {
                            extBtnNext: chrome.i18n.getMessage("extBtnNext"),
                            extPause: chrome.i18n.getMessage("extPause"),
                            class_next_step: class_next_step
                        })
                    );

                    button = $(".uxc_item_next");
                    localStorage.setItem("uxc_update_time", "true");
                    event = "nextStep";
                }

                console.log(chrome.i18n.getMessage("extTaskNumber"));

                $(".uxc_question").html(
                    $.parseHTML(tmpl("uxc_all_question", {
                        extTaskNumber: chrome.i18n.getMessage("extTaskNumber"),
                        all_questions: config.mainPageSteps[config.activeStep - 1],
                        activeStep: config.activeStep,
                        allStep: config.mainPageSteps.length
                    }))
                );
            }

            $(".uxc_close").click(function() {
                uxc_work = false;

                $(".container_mic").hide();
                $(".uxc_question").html(chrome.i18n.getMessage("extMessage010"));
                $(".uxc_panel_btn").html(
                    tmpl("UXC_tmpl_forcedShutdown", {
                        extBtnYes: chrome.i18n.getMessage("extBtnYes"),
                        extBtnNo: chrome.i18n.getMessage("extBtnNo")
                    })
                );

                $(".UXC_tmpl_forcedShutdown_yes").click(function() {
                  setBackgroundNotConfig("breakTest");
                });

                $(".UXC_tmpl_forcedShutdown_no").click(function() {
                    uxc_work = true;
                    setBackground("openPopup");
                    $(".container_mic").show();
                });
            });

            var obj_question = config.mainPageSteps[config.activeStep - 1];

            switch (obj_question.stepType) {
                case "TEXT":
                    $(button).unbind();

                    $(button).click(function() {
                        if (!$(this).hasClass("disabled")) {
                            setBackground(event);
                        }
                    });

                    break;
                case "RATING":
                    $(button).unbind();

                    $(button).click(function() {
                        value = $("input:radio[name ='uxc_item_rating_radio_group']:checked").val();

                        if (!value || value <= 0) {
                            $("#block_error").text(chrome.i18n.getMessage("extMessage011"));
                        } else {
                            $("#block_error").text("");
                            if (!$(this).hasClass("disabled")) {
                                setBackground(event, value);
                            }
                        }
                    });

                    $(".uxc_rating_btn_custom").click(function() {
                        var value_radio = $(this)
                            .children("input")
                            .val();

                        localStorage.setItem("activeStep", config.activeStep);
                        localStorage.setItem("uxc_text_rating", value_radio);

                        $(".uxc_rating_btn_custom.active").removeClass("active");
                        $(this).addClass("active");
                        $(this)
                            .children("input")
                            .prop("checked", true);

                        for (var i = 0; i < value_radio; i++) {
                            $(".uxc_rating_btn_custom:eq(" + i + ")").addClass("active");
                        }
                    });

                    if (localStorage.getItem("activeStep") == config.activeStep) {
                        if (localStorage.getItem("uxc_text_rating")) {
                            console.log(Number(localStorage.getItem("uxc_text_rating")));

                            $("input:radio[name ='uxc_item_rating_radio_group']:eq(" + (Number(localStorage.getItem("uxc_text_rating")) - 1) + ")").prop("checked", true);

                            for (var i = 0; i < Number(localStorage.getItem("uxc_text_rating")); i++) {
                                $(".uxc_rating_btn_custom:eq(" + i + ")").addClass("active");
                            }
                        }
                    }

                    break;
                case "ANSWER":
                    $("#uxc_item_answer_textarea").on("change, keyup", function() {
                        localStorage.setItem("activeStep", config.activeStep);
                        localStorage.setItem("uxc_text_textarea", $("#uxc_item_answer_textarea").val());
                    });

                    $(button).unbind();

                    $(button).click(function() {
                        value = $("#uxc_item_answer_textarea").val();
                        if (!$(this).hasClass("disabled")) {
                            if (!value || value.length == 0) {
                                $("#block_error").text(chrome.i18n.getMessage("extMessage012"));
                            } else {
                                $("#block_error").text("");
                                localStorage.setItem("uxc_text_textarea", "");
                                setBackground(event, value);
                            }
                        }
                    });

                    if (localStorage.getItem("activeStep") == config.activeStep) {
                        if (localStorage.getItem("uxc_text_textarea")) {
                            $("#uxc_item_answer_textarea").val(localStorage.getItem("uxc_text_textarea"));
                        }
                    }

                    break;
                case "RADIO":
                    $(".uxc_rating_btn_custom_input").click(function() {
                        var num_radio = $(this)
                            .children("input")
                            .data("num-radio");

                        $(".uxc_rating_btn_custom_input.active").removeClass("active");
                        $(this).addClass("active");
                        $(this)
                            .children("input")
                            .prop("checked", true);

                        localStorage.setItem("activeStep", config.activeStep);
                        localStorage.setItem("uxc_text_radio", num_radio);
                    });

                    $(button).unbind();

                    $(button).click(function() {
                        value = $("input:radio[name ='uxc_item_radio_group']:checked").val();

                        if (!value) {
                            $("#block_error").text(chrome.i18n.getMessage("extMessage012"));
                        } else {
                            $("#block_error").text("");
                            if (!$(this).hasClass("disabled")) {
                                setBackground(event, value);
                            }
                        }
                    });

                    if (localStorage.getItem("activeStep") == config.activeStep) {
                        if (localStorage.getItem("uxc_text_radio")) {
                            var el = $("input:radio[data-num-radio =" + localStorage.getItem("uxc_text_radio") + "]");

                            $(el)
                                .parent("div")
                                .addClass("active");
                            $(el).prop("checked", true);
                        }
                    }

                    break;
                case "CHECKBOX":
                    $(".uxc_rating_btn_custom_input_checkbox").click(function() {
                        var array_checkbox = [];

                        if ($(this).children("input").prop("checked")) {
                            $(this)
                                .children("input")
                                .prop("checked", false);

                            $(this).removeClass("active");
                        } else {
                            $(this)
                                .children("input")
                                .prop("checked", true);

                            $(this).addClass("active");
                        }

                        $(".uxc_rating_btn_custom_input_checkbox input:checked").each(function() {
                            array_checkbox.push($(this).data("num-checkbox"));
                        });

                        localStorage.setItem("activeStep", config.activeStep);
                        localStorage.setItem("uxc_text_checkbox", JSON.stringify(array_checkbox));

                        console.log(array_checkbox);
                    });

                    $(button).unbind();

                    $(button).click(function() {
                        value = $("input:checkbox[name ='uxc_item_checkbox']:checked")
                            .map(function() {
                                return $(this).val();
                            })
                            .get();

                        if (!value || value.length == 0) {
                            $("#block_error").text(chrome.i18n.getMessage("extMessage012"));
                        } else {
                            $("#block_error").text("");

                            if (!$(this).hasClass("disabled")) {
                                setBackground(event, value);
                            }
                        }
                    });

                    if (localStorage.getItem("activeStep") == config.activeStep) {
                        if (localStorage.getItem("uxc_text_checkbox")) {
                            var array_checkbox = JSON.parse(localStorage.getItem("uxc_text_checkbox"));

                            console.log(array_checkbox);

                            for (var i in array_checkbox) {
                                var el = $("input:checkbox[data-num-checkbox =" + array_checkbox[i] + "]");

                                $(el)
                                    .parent("div")
                                    .addClass("active");
                                $(el).prop("checked", true);
                            }
                        }
                    }

                    break;
            }

            $(".uxc_item_pause").click(function() {
                console.log('clicked pause');
                uxc_work = false;
                setBackground("pauseRec");
            });

            break;
        case "pause":
            clearQuestionContainer();

            $(".uxc_panel_btn").html(
                tmpl("UXC_tmpl_btn_resume", {
                    extBtnContinue: chrome.i18n.getMessage("extBtnContinue")
                })
            );

            $(".uxc_item_resume").click(function() {
                uxc_work = true;
                setBackground("resumeRec");
            });

            break;
        case "selectDesktop":
            //clearQuestionContainer();
            $(".UXC_Plugins").remove();
            $(".uxc_panel_btn").html(
                tmpl("UXC_tmpl_select_desktop", {
                    extRequest: chrome.i18n.getMessage("extRequest")
                })
            );

            $(".uxc_close").click(function() {
                setBackgroundNotConfig("forcedShutdown");
            });

            break;
    }

    UXC_position();
}

function UXC_position() {
    var UXC_block = document.getElementsByClassName("UXC_Plugins")[0];
    var UXC_block_item = document.getElementsByClassName("uxc_line_position")[0];
    var UXC_resizing_block = document.getElementsByClassName("resizing_block")[0];

    var default_x, default_y;

    delta_x = 0;
    delta_y = 0;
    /* Ставим обработчики событий на нажатие и отпускание клавиши мыши */
    UXC_block_item.onmousedown = saveXY;
    //UXC_resizing_block.onmousedown = resizeXY;

    document.onmouseup = clearXY;

    /* При нажатии кнопки мыши попадаем в эту функцию */
    function saveXY(obj_event) {
        /* Получаем текущие координаты курсора */
        if (obj_event) {
            x = obj_event.pageX;
            y = obj_event.pageY;
        } else {
            x = window.event.clientX;
            y = window.event.clientY;
        }
        /* Узнаём текущие координаты блока */
        x_block = UXC_block.offsetLeft;
        y_block = UXC_block.offsetTop;
        /* Узнаём смещение */
        delta_x = x_block - x;
        delta_y = y_block - y;
        /* При движении курсора устанавливаем вызов функции moveWindow */
        document.onmousemove = moveBlock;
    }

    function clearXY() {
        document.onmousemove = null; // При отпускании мыши убираем обработку события движения мыши
    }

    function moveBlock(obj_event) {
        /* Получаем новые координаты курсора мыши */
        if (obj_event) {
            x = obj_event.pageX;
            y = obj_event.pageY;
        } else {
            x = window.event.clientX;
            y = window.event.clientY;
        }
        /* Вычисляем новые координаты блока */
        new_x = delta_x + x;
        new_y = delta_y + y;
        UXC_block.style.top = new_y + "px";
        UXC_block.style.left = new_x + "px";
    }

    function resizeXY(obj_event) {
        /* Получаем текущие координаты курсора */
        if (obj_event) {
            x = obj_event.pageX;
            y = obj_event.pageY;
        } else {
            x = window.event.clientX;
            y = window.event.clientY;
        }
        default_x = x;
        default_y = y;

        /* При движении курсора устанавливаем вызов функции moveWindow */
        document.onmousemove = moveBlockResize;
    }

    function moveBlockResize(obj_event) {
        /* Получаем новые координаты курсора мыши */
        if (obj_event) {
            x = obj_event.pageX;
            y = obj_event.pageY;
        } else {
            x = window.event.clientX;
            y = window.event.clientY;
        }

        $("#UXC_Plugins").width(default_x - x);
        $("#UXC_Plugins").height(default_y + y);
    }
}

//Отправка в DOM (injected_modal.js)
function setDom(code, tabId) {
    chrome.tabs.executeScript(tabId, { code: code });
}

//Отправка в Background.js
function setBackground(eventPage, answerValue) {
    if (eventPage == "stopRec") {
        uxc_work = true;
    }

    chrome.runtime.sendMessage({ eventPage: eventPage, answerValue: answerValue }, function(obj) {
        if (obj && obj.config) {
            renderPopup(obj.config);
        }

        return obj;
    });
}

function setBackgroundNotConfig(eventPage, answerValue) {
    chrome.runtime.sendMessage({ eventPage: eventPage, answerValue: answerValue }, function(obj) {});
}
