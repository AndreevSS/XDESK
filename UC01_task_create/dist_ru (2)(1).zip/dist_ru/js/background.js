// functions.js

var formattedCurrentTime = "0:00";
var _log = console.log;
var _error = console.error;
var _warn = console.warn;

var resolutions = {
    maxWidth: 1366,
    maxHeight: 768
};

var aspectRatio = 1.77,
    audioBitsPerSecond = 0,
    videoBitsPerSecond = 0,
    enableTabAudio = false,
    enableMicrophone = false,
    audioStream = false,
    bitsPerSecond = 0,
    enableTabCaptureAPI = false,
    enableCamera = false,
    enableSpeakers = true,
    enableScreen = true,
    enableMicrophone = true,
    videoCodec = "Default",
    videoMaxFrameRates = "",
    microphoneDevice = false,
    cameraDevice = false,
    recorder,
    isRecording = false,
    bitsPerSecond = 0,
    isChrome = true, // used by RecordRTC
    enableTabCaptureAPI = false,
    enableScreen = true,
    enableMicrophone = true,
    enableCamera = false,
    cameraStream = false,
    enableSpeakers = true,
    mimeType = "video/webm;codecs=vp9",
    fileExtension = "webm",
    recorderType = null,
    type = "video",
    videoCodec = "Default",
    videoMaxFrameRates = "",
    isRecordingVOD = false,
    startedVODRecordedAt = new Date().getTime(),
    videoPlayers = [];

var userId = null;
var globalStream = null;

var audioPlayer, context, mediaStremSource, mediaStremDestination;

var firstStep = false;
var firstStepPopup = false;

var local_save_video_user = false,
    test_tab_id;

var systemInfo = {
    archName: null,
    numOfProcessors: null,
    os: null,
    processorModel: null,
    browserVersion: null,
    screenResolution: null,
    geoLocation: null
};

var microBroken = false;
var scena;

var f = debounce(f, 200);

var recorder;
var scriptProcessor;
var silenceCounter = 0;
var peer;

var isRecording = false;
var images = ["recordRTC-progress-1.png", "recordRTC-progress-2.png", "recordRTC-progress-3.png", "recordRTC-progress-4.png", "recordRTC-progress-5.png"];
var imgIndex = 0;
var reverse = false;

var initialTime, timer, cpuUsageTimer;

var alreadyHadGUMError = false;

var pending = [];

var backPeerInitialized = false;

var _a = chrome.browserAction,
    setTitle = _a.setTitle,
    setIcon = _a.setIcon;

var __awaiter =
    (this && this.__awaiter) ||
    function(thisArg, _arguments, P, generator) {
        return new(P || (P = Promise))(function(resolve, reject) {
            function fulfilled(value) {
                try {
                    step(generator.next(value));
                } catch (e) {
                    reject(e);
                }
            }

            function rejected(value) {
                try {
                    step(generator["throw"](value));
                } catch (e) {
                    reject(e);
                }
            }

            function step(result) {
                result.done ?
                    resolve(result.value) :
                    new P(function(resolve) {
                        resolve(result.value);
                    }).then(fulfilled, rejected);
            }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };

var processorsFromCB;

console.log = function() {
    var args = arguments;
    var completeString = getCompleteString(arguments);

    Array.prototype.unshift.call(arguments, completeString);
    _log.apply(this, arguments);
};

console.error = function() {
    var args = arguments;
    var completeString = getCompleteString(arguments);

    Array.prototype.unshift.call(arguments, completeString);
    _error.apply(this, arguments);
};

console.warn = function() {
    var args = arguments;
    var completeString = getCompleteString(arguments);

    Array.prototype.unshift.call(arguments, completeString);
    _warn.apply(this, arguments);
};

// ///////////////////////////////////////////////////////////////////////// //
// FUNCTIONS
// ///////////////////////////////////////////////////////////////////////// //

//*1 мониторинг загрузки памяти и процессора. скопировано от сюда - https://github.com/pd4d10/system-monitor
var __generator =
    (this && this.__generator) ||
    function(thisArg, body) {
        var _ = {
                label: 0,
                sent: function() {
                    if (t[0] & 1) throw t[1];
                    return t[1];
                },
                trys: [],
                ops: []
            },
            f,
            y,
            t,
            g;
        return (
            (g = {
                next: verb(0),
                throw: verb(1),
                return: verb(2)
            }),
            typeof Symbol === "function" &&
            (g[Symbol.iterator] = function() {
                return this;
            }),
            g
        );

        function verb(n) {
            return function(v) {
                return step([n, v]);
            };
        }

        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_)
                try {
                    if (((f = 1), y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done)) return t;
                    if (((y = 0), t)) op = [0, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return {
                                value: op[1],
                                done: false
                            };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!((t = _.trys), (t = t.length > 0 && t[t.length - 1])) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2]) _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                } catch (e) {
                    op = [6, e];
                    y = 0;
                } finally {
                    f = t = 0;
                }
            if (op[0] & 5) throw op[1];
            return {
                value: op[0] ? op[1] : void 0,
                done: true
            };
        }
    };

function getCpuUsage(processors, processorsOld) {
    var usage = [];
    for (var i = 0; i < processors.length; i++) {
        var processor = processors[i];
        var processorOld = processorsOld[i];
        usage.push(
            processorOld ?
            {
                user: processor.user - processorOld.user,
                kernel: processor.kernel - processorOld.kernel,
                idle: processor.idle - processorOld.idle,
                total: processor.total - processorOld.total
            } :
            processor
        );
    }
    return usage;
}

function setTitleVersion() {
    $.getJSON("../manifest.json", function(data) {
        chrome.browserAction.setTitle({
            title: "UXCrowd Recorder: " + data.version
        });
    });
}
setTitleVersion();

function serverError() {
    chrome.tabs.update(UXC_main_config.mainUxcTabId, {active: true});
    chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, { eventPage: 'error'});
};

function getCompleteString(arguments) {
    var completeString = "";

    var callerName = "background.js";

    if (arguments.callee.caller != null) {
        callerName = arguments.callee.caller.name;
        if (callerName == null || callerName == "") {
            callerName = "anonymous";
        }
    }

    var err = new Error();
    Error.captureStackTrace(err);

    // Throw away the first line of the trace
    var frames = err.stack.split("\n").slice(1);
    __filename = frames[2].split("/")[frames[2].split("/").length - 1].split(":")[0];

    line = frames[2].substring(frames[2].indexOf(__filename), frames[2].length - 1);

    completeString = formattedCurrentTime + " - <" + callerName + ">, " + line + "; " + completeString;

    return completeString;
}

function getOSInfo(appVer) {
    var strComp = appVer;
    str1 = strComp.split("(").join(";");
    str2 = str1.split(")").join(";");
    str3 = str2.split("/").join(";");
    arrStr = str3.split(";");
    var str1 = arrStr[1];
    var str2 = "NA";
    var str3 = "";
    var str4 = arrStr[1].substring(0, 7);
    var str5 = arrStr[2];
    var verOS = "Chrome OS Version: ";
    var os = "";
    var ver = "Chrome ";
    if (str1 == "X11") {
        str2 = arrStr[2].substring(12, 25);
    }
    if (str1 == "X11") {
        str3 = navigator.platform + " (Chrome Book)";
    } else {
        str3 = arrStr[2];
        if (str3 == "WOW64") {
            str3 = "Windows 32-bit on Windows 64-bit";
        }
    }

    if ((str4 = "Windows" && str5 == " Win64")) {
        os = os + str1 + " " + str3;
        browserVersion = ver + arrStr[8].split(" ")[0];
        retStr = os + "; " + browserVersion + "; " + verOS + str2;
    } else {
        os = os + str1 + " " + str3;
        browserVersion = ver + arrStr[7].split(" ")[0];
        retStr = os + "; " + browserVersion + "; " + verOS + str2;
    }

    systemInfo.os = os;
    systemInfo.browserVersion = browserVersion;
    systemInfo.screenResolution = screen.width + "x" + screen.height;

    return retStr;
}

function trigger(cb, processorsOld) {
    if (processorsOld === void 0) {
        processorsOld = [];
    }
    return __awaiter(this, void 0, void 0, function() {
        var cpuP, memoryP, storageP, _a, cpu, memory, storage, processors, cpuUsage, data;
        return __generator(this, function(_b) {
            switch (_b.label) {
                case 0:
                    cpuP = new Promise(function(resolve) {
                        return chrome.system.cpu.getInfo(resolve);
                    });
                    memoryP = new Promise(function(resolve) {
                        return chrome.system.memory.getInfo(resolve);
                    });
                    storageP = new Promise(function(resolve) {
                        return chrome.system.storage.getInfo(resolve);
                    });
                    return [4 /*yield*/ , Promise.all([cpuP, memoryP, storageP])];
                case 1:
                    (_a = _b.sent()), (cpu = _a[0]), (memory = _a[1]), (storage = _a[2]);

                    processors = cpu.processors.map(function(_a) {
                        var usage = _a.usage;
                        return usage;
                    });
                    cpuUsage = getCpuUsage(processors, processorsOld);
                    data = {
                        cpu: {
                            modelName: cpu.modelName,
                            usage: cpuUsage
                        },
                        memory: memory,
                        storage: storage
                    };
                    cb(data, processors);
                    return [2 /*return*/ ];
            }
        });
    });
}

function getCPUAndMemoryUsage() {
    trigger(function(_a, processors) {
        var _b = _a.cpu,
            modelName = _b.modelName,
            usage = _b.usage;
        var idle = usage.reduce(function(a, b) { return a + b.idle / b.total; }, 0) / usage.length;

        processorsFromCB = processors;

        var capacity = _a.memory.capacity,
            availableCapacity = _a.memory.availableCapacity;

        console.log("CPU usage: " + (100 * (1 - idle)).toFixed(0) + "%" + " Memory: capacity-" + (capacity / (1024 * 1024 * 1024)).toFixed(2) + "GB, availableCapacity-" + (availableCapacity / (1024 * 1024 * 1024)).toFixed(2) + "GB");
    }, processorsFromCB);
}

function authorization_uxc(typeEvent) {
    console.log("authorization_uxc");
    console.log("typeEvent", typeEvent);

    if (UXC_main_config.user.csrf_token == undefined || typeEvent != "setTask") {
        $.ajax({
            type: "GET",
            url: UXC_main_config.url + "/api/account",
            async: false,
            success: function(data) {
                console.log("GET /api/account", data);

                if (data.role == "ROLE_TESTER" || data.role == "ROLE_SIDE_TESTER") {
                    UXC_main_config.tester_role = data.role;
                    UXC_main_config.user.authorization = true;

                    chrome.cookies.get({
                        url: UXC_main_config.url,
                        name: "XSRF-TOKEN"
                    }, function(cookie) {
                        UXC_main_config.user.csrf_token = cookie.value;
                        if (typeEvent != "reloadOfForbidden") {
                            setOrderTask();
                        } else {
                            sendForbidden();
                        }
                    });
                } else {
                    if (data.role == "ROLE_NEW_TESTER" || data.role == "ROLE_LOCKED_TESTER") {
                        UXC_main_config.user.authorization = true;

                        chrome.cookies.get({
                            url: UXC_main_config.url,
                            name: "XSRF-TOKEN"
                        }, function(cookie) {
                            UXC_main_config.user.csrf_token = cookie.value;
                            if (typeEvent != "reloadOfForbidden") {
                                setOrderTask();
                            } else {
                                sendForbidden();
                            }
                        });
                    }
                }
            },
            error: function(data, textStatus, request) {
                console.log(data, textStatus, request);

                UXC_main_config.user.authorization = false;

                if (data.status == 401) {
                    sendForbidden(true);
                }
            }
        });
    }

    console.log("UXC_main_config.user.csrf_token == undefined || typeEvent != 'setTask'");
}

function microOK() {
    console.log("microOK");

    $.getJSON("../manifest.json", function(data) {
        console.log("UXCrowd Recorder version: " + data.version);
    });

    chrome.tabs.onCreated.addListener(function(tab) {
        UXC_main_config.arrayTabRec.push(tab.id);
    });

    if (localStorage.getItem("UXC_ver") != "0") {
        console.log('localStorage.getItem("UXC_ver")', localStorage.getItem("UXC_ver"));

        if (UXC_main_config.statusRec == "default") {
            authorization_uxc();
        }
    } else {
        localStorage.setItem("uxc_first_orderId", request.orderId);
        local_save_video_user = true;

        first_start_and_update();
    }

    return;
}

function microNotOK(mainTabId, errorName) {
    console.log("microNotOK");

    chrome.tabs.sendMessage(mainTabId, {
        eventPage: "microNotOk",
        errorName: errorName
    });
}

function forcedShutdown() {
    console.log("forcedShutdown");
    for (var i in UXC_main_config.arrayTabRec) {
        if (UXC_main_config.arrayTabRec.hasOwnProperty(i)) {
            chrome.tabs.remove(UXC_main_config.arrayTabRec[i]); //Закрыли таб с которого писали
        }
    }
    if (UXC_main_config.orderId) {
        if (UXC_main_config.orderId == 1 || UXC_main_config.orderId == 2 || UXC_main_config.orderId == 3 || UXC_main_config.orderId == 4 || UXC_main_config.orderId == 5 || UXC_main_config.orderId == 6) {
            if (UXC_main_config.idTab) {
                chrome.tabs.remove(Number(UXC_main_config.idTab)); //Закрыли таб с которого писали
            }

            chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
                eventPage: "reloadPageRec"
            });

            location.reload();
        } else {
            $.ajax({
                type: "DELETE",
                url: UXC_main_config.url + "/api/tester/remove-active-task",
                data: {
                    orderId: UXC_main_config.orderId
                },
                success: function(data) {
                    if (UXC_main_config.idTab) {
                        chrome.tabs.remove(UXC_main_config.idTab); //Закрыли таб с которого писали
                    }

                    chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
                        eventPage: "reloadPageRec"
                    });

                    location.reload();
                },
                error: function(data) {
                    if (UXC_main_config.idTab) {
                        chrome.tabs.remove(Number(UXC_main_config.idTab)); //Закрыли таб с которого писали
                    }

                    chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
                        eventPage: "reloadPageRec"
                    });

                    location.reload();
                }
            });
        }
    } else {
        location.reload();
    }
}

function open_final_modal() {
    if (UXC_main_config.idTab && UXC_main_config.mainUxcTabId) {
        for (var i in UXC_main_config.arrayTabRec) {
            chrome.tabs.remove(UXC_main_config.arrayTabRec[i]);
        }

        chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
            eventPage: "openFinalModal"
        }); //Открыли прелоадер на главном

        chrome.tabs.update(UXC_main_config.mainUxcTabId, {
            active: true
        }); //Передали фокус главному окну
    }

    UXC_main_config.arrayTabRec = [];
}

function setOrderTask() {
    console.log("setOrderTask()");
    console.log("GET /api/tester/order-info?id=", UXC_main_config.orderId);

    $.ajax({
        url: UXC_main_config.url + "/api/tester/order-info?id=" + UXC_main_config.orderId,
        method: "GET",
        dataType: "json",
        async: false,
        success: function(data) {

            // Сортируем надписи в правильном порядке
            if (data && data.steps) {
                data.steps = data.steps.map(function(next) {
                    if (next.stepDetails && next.stepDetails.length > 0) {
                        next.stepDetails.sort(function(a, b) {
                            if (a.orderNum > b.orderNum) {
                                return 1;
                            }
                            if (a.orderNum < b.orderNum) {
                                return -1;
                            }
                            return 0;
                        })
                    }
                    return next;
                })
            }

            UXC_main_config.mainPageUrl = data.url;

            if (data.type != null && (data.type == "ANDROID" || data.type == "MOBILE") && data.testertype != "THEIR") {
                UXC_main_config.mainPageUrl = UXC_main_config.url + "/mobile-tester-welcome/welcome?url=" +
                    data.url + "&orderId=" + UXC_main_config.orderId;
                data.steps.unshift({
                    id: -1,
                    stepDetails: [
                      {
                        id: -1,
                        value: chrome.i18n.getMessage("extInstruct"),
                        orderNum: 0
                      }
                    ],
                    orderNum: 1,
                    stepType: "TEXT"
                });
            }

            UXC_main_config.mainPageSteps = data.steps;
            if (UXC_main_config.mainPageSteps == null) {
              console.log(window);
              UXC_open_modal(chrome.i18n.getMessage('extEmptyScenario'));
              return;
            }

            if (data.requirements != "null") {
              UXC_main_config.requirements =
                data.requirements;
              if (UXC_main_config.statusRec != "rec") {
                mainTab();
              }
            }
        },
        error: function(data) {
            console.log("error", data);
            serverError();
        }
    });
}

function mainTab(UXCevent) {
    console.log("mainTab()");

    chrome.tabs.query({}, function(tab) {
        if (UXCevent == "no_show_info") {
            setTimeout(function() {
                chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
                    eventPage: "show_select_window"
                });

                chrome.tabs.update(UXC_main_config.mainUxcTabId, {
                    active: true
                });
            }, 1000);
        }

        if (UXCevent != "error" && UXCevent != "no_show_info") {
            chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
                eventPage: "show_info",
                tester_role: UXC_main_config.tester_role
            });
        }

        if (UXCevent == "error") {
            chrome.tabs.sendMessage(Number(UXC_main_config.mainUxcTabId), {
                statusRecEl: "false"
            }, function() {});

            location.reload();
        }
    });
}

function first_start() {
    console.log("first_start");
    $.ajax({
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
        },
        url: UXC_main_config.url + "/api/tester/create-task?orderId=" + UXC_main_config.orderId,
        method: "POST",
        data: JSON.stringify(systemInfo),
        dataType: "json",
        beforeSend: function(xhr) {
            xhr.setRequestHeader("X-XSRF-TOKEN", UXC_main_config.user.csrf_token);
        },
        async: false,
        success: function(data) {
            UXC_main_config.taskIdResponse = data.id;

            if (UXC_main_config.mainPageUrl.split(".")[0] == "www") {
                UXC_main_config.newMainPageUrl = "http://" + UXC_main_config.mainPageUrl;
            } else {
                if (UXC_main_config.mainPageUrl.split(":")[0] == "https") {
                    UXC_main_config.newMainPageUrl = UXC_main_config.mainPageUrl;
                } else {
                    if (UXC_main_config.mainPageUrl.split(":")[0] == "http") {
                        UXC_main_config.newMainPageUrl = UXC_main_config.mainPageUrl;
                    } else {
                        UXC_main_config.newMainPageUrl = "http://" + UXC_main_config.mainPageUrl;
                    }
                }
            }

            UXC_main_config.mainPageUrl = UXC_main_config.newMainPageUrl;

            chrome.tabs.create({ url: UXC_main_config.mainPageUrl }, function(tab) {
                chrome.tabs.update(UXC_main_config.mainUxcTabId, {
                    active: true
                });
                UXC_main_config.idTab = tab.id;
                UXC_main_config.allTime.push({
                    startTime: "00:00:00",
                    orderNum: UXC_main_config.mainPageSteps[0].orderNum,
                    answerValue: null
                });
                getUserConfigs();
            });
            update_stats({screenName: "FINAL_INSTRUCTION"})
        },
        error: function(data) {
            chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
                statusRecEl: "false"
            });

            console.log(data);
        }
    });
}
function update_stats(params) {
    const statsId = UXC_main_config.statsId;
    const orderId = UXC_main_config.orderId;
    const reqBody = {
        orderId,
        id: statsId,
        ...params
    }
    $.ajax({
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
        },
        url: UXC_main_config.url + "/api/stats/update",
        method: "PUT",
        data: JSON.stringify(reqBody),
        dataType: "json",
        beforeSend: function(xhr) {
            xhr.setRequestHeader("X-XSRF-TOKEN", UXC_main_config.user.csrf_token);
        },
        async: false
    });
}
function addTimeAndValue(value) {
    console.log("addTimeAndValue");

    var timeObject = UXC_main_config.allTime.pop();
    timeObject.answerValue = value;

    UXC_main_config.allTime.push(timeObject);
    UXC_main_config.allTime.push({
        startTime: "00:" + UXC_main_config.mainTimeVideo,
        orderNum: UXC_main_config.orderNum,
        answerValue: null
    });

    for (var i in UXC_main_config.arrayTabRec) {
        if (UXC_main_config.arrayTabRec.hasOwnProperty(i)) {
            chrome.tabs.sendMessage(UXC_main_config.arrayTabRec[i], {
                eventPage: "update",
                config: UXC_main_config
            });
        }
    }
}

function createSteps() {
    console.log("createSteps");

    var fullStepAndTime = [];
    var steps = UXC_main_config.mainPageSteps;

    for (var num in steps) {
        fullStepAndTime.push({
            orderNum: steps[num].orderNum,
            stepId: steps[num].id,
            startTime: UXC_main_config.allTime[num].startTime,
            answer: UXC_main_config.allTime[num].answerValue
        });
    }

    return fullStepAndTime;
}

function stopRec() {
    console.log("stopRec");
    stopScreenRecording();
}

function sendVideo(success, fail) {
    console.log("sendVideo");

    var statusSend = true;
    scena = createSteps();
    var formData = new FormData();

    formData.append("task-id", UXC_main_config.taskIdResponse);
    formData.append("video-file", UXC_main_config.localSaveBlob);
    formData.append("name", formData.get("video-file").name + ".webm");
    formData.append("tag-dto", new Blob([JSON.stringify(scena)], {type : 'application/json'}));

    var xhr = new XMLHttpRequest();
    xhr.upload.onprogress = function(event) {
        console.log("Загружено на сервер", event.loaded + " байт из " + event.total);

        var percent = event.loaded / event.total * 100;
        if (statusSend) {
            chrome.tabs.sendMessage(Number(UXC_main_config.mainUxcTabId), {
                eventPage: "progress",
                progress: percent
            });
        }
    };

    xhr.open("POST", UXC_main_config.url + "/api/video-upload-app", true);
    xhr.setRequestHeader("X-XSRF-TOKEN", UXC_main_config.user.csrf_token);

    xhr.onreadystatechange = function() {
        console.log("xhr", xhr);
        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
            chrome.tabs.sendMessage(Number(UXC_main_config.mainUxcTabId), {
                eventPage: "endRec",
                config: UXC_main_config
            });
            success();
        } else {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status == 403) {
                    UXC_main_config.user.authorization = false;
                    var response = chrome.i18n.getMessage("extPleaseAuth");

                    chrome.tabs.sendMessage(Number(UXC_main_config.mainUxcTabId), {
                        eventPage: "sendFail",
                        text: response
                    });
                } else {
                    statusSend = false;
                    var response = chrome.i18n.getMessage("extUploadError");
                    
                    chrome.tabs.sendMessage(Number(UXC_main_config.mainUxcTabId), {
                        eventPage: "sendFail",
                        text: response
                    });
                    fail(response)
                }
            }
        }
    };
    xhr.send(formData);
}

function sendForbidden(error) {
    if (error) {
        var response = chrome.i18n.getMessage("extPleaseAuth");

        chrome.tabs.sendMessage(Number(UXC_main_config.mainUxcTabId), {
            eventPage: "sendFail",
            text: response
        });
    } else {
        sendVideo();
    }
}

function setScript(eventPage, object, objWin, url) {
    chrome.runtime.sendMessage({
        eventPage: eventPage,
        obj: object,
        objWin: objWin,
        url: url
    }, function(obj) {
        return obj;
    });
}

function debounce(f, ms) {
    var state = null;
    var cooldown = 1;

    return function() {
        if (state) return;

        f.apply(this, arguments);
        state = cooldown;
        setTimeout(function() {
            state = null;
        }, ms);
    };
}

function f(x) {
    chrome.runtime.sendMessage({
        eventPage: "UXC_mic_progress",
        progress: x
    });

    for (var i in UXC_main_config.arrayTabRec) {
        chrome.tabs.sendMessage(UXC_main_config.arrayTabRec[i], {
            eventPage: "UXC_mic_progress",
            progress: x
        });
    }
}

function local_save_video() {
    invokeSaveAsDialog(UXC_main_config.localSaveBlob, UXC_main_config.name_blob);
    //chrome.tabs.sendMessage(Number(localStorage.getItem('stopedTab')), {statusSave: "true"});
}

function stopScreenRecording(in_final) {
    console.log("stopScreenRecording");
    isRecording = false;

    recorder.stopRecording(function() {
        console.log("recorder.stopRecording");

        if (!local_save_video_user) {
            var file = new File([recorder.getBlob()], "UXCrowd-" + new Date().toISOString().replace(/:|\./g, "-") + ".webm", {
                type: mimeType
            });

            invokeSaveAsDialog(file, file.name);
        }
        UXC_main_config.localSaveBlob = recorder.blob;
        UXC_main_config.name_blob = "UXCrowd-" + new Date().toISOString().replace(/:|\./g, "-") + ".webm";

        if (!in_final) {
            update_stats({ screenName: "COMPLETE_TEST" });
            open_final_modal();
        }

        try {
            peer.close();
            peer = null;
        } catch (e) {}

        try {
            audioPlayer.src = null;
            mediaStremDestination.disconnect();
            mediaStremSource.disconnect();
            context.disconnect();
            context = null;
        } catch (e) {}

        try {
            videoPlayers.forEach(function(player) {
                player.src = null;
            });
            videoPlayers = [];
        } catch (e) {}
    });

    if (timer) {
        clearTimeout(timer);
    }

    if (cpuUsageTimer) {
        clearTimeout(cpuUsageTimer);
    }

    setTimeout(function() {
        setDefaults();
    }, 1000);

    setBadgeText("");
}

function setDefaults() {
    console.log("setDefaults");

    chrome.browserAction.setIcon({
        path: "images/main-icon.png"
    });

    if (recorder && recorder.stream) {
        recorder.stream.stop();
        if (recorder && recorder.stream && recorder.stream.onended) {
            recorder.stream.onended();
        }
    }

    setTitleVersion();

    recorder = null;
    isRecording = false;
    imgIndex = 0;
}

function onRecording() {
    chrome.browserAction.setIcon({
        path: "images/" + images[imgIndex]
    });

    if (!reverse) {
        imgIndex++;

        if (imgIndex > images.length - 1) {
            imgIndex = images.length - 1;
            reverse = true;
        }
    } else {
        imgIndex--;

        if (imgIndex < 0) {
            imgIndex = 1;
            reverse = false;
        }
    }

    if (isRecording) {
        setTimeout(onRecording, 800);
        return;
    }

    chrome.browserAction.setIcon({
        path: "images/main-icon.png"
    });
}

function setBadgeText(text) {
    chrome.browserAction.setBadgeBackgroundColor({
        color: [255, 0, 0, 255]
    });

    chrome.browserAction.setBadgeText({
        text: text + ""
    });
}

function mainTimeVideo(time) {
    if (time.split(":")[0].length === 1) {
        time = "0" + time.split(":")[0] + ":" + time.split(":")[1];
    }

    UXC_main_config.mainTimeVideo = time;
}

function checkTime() {
    if (!UXC_main_config.on_pause) {
        if (!initialTime) return;

        var timeDifference = Date.now() - initialTime - Number(allTimePause());
        formattedCurrentTime = convertTime(timeDifference);

        mainTimeVideo(formattedCurrentTime);
        setBadgeText(formattedCurrentTime);

        chrome.browserAction.setTitle({
            title: "Recording duration: " + formattedCurrentTime
        });
    }
}

function allTimePause() {
    return UXC_main_config.allTimePause;
}

function startPause() {
    UXC_main_config.on_pause = true;
    Date.now();
    UXC_main_config.startTimePause = Date.now();
}

function stopPause() {
    UXC_main_config.on_pause = false;
    var allPause = Date.now() - Number(UXC_main_config.startTimePause) + Number(UXC_main_config.allTimePause);
    UXC_main_config.allTimePause = allPause;
}

function convertTime(miliseconds) {
    var totalSeconds = Math.floor(miliseconds / 1000);
    var minutes = Math.floor(totalSeconds / 60);
    var seconds = totalSeconds - minutes * 60;

    minutes += "";
    seconds += "";

    if (seconds.length === 1) {
        seconds = "0" + seconds;
    }

    return minutes + ":" + seconds;
}

function getChromeVersion() {
    var raw = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);

    return raw ? parseInt(raw[2], 10) : 52;
}

function initVideoPlayer(stream) {
    var videoPlayer = document.createElement("video");

    videoPlayer.muted = !enableTabCaptureAPI;
    videoPlayer.volume = !!enableTabCaptureAPI;
    try {
        videoPlayer.srcObject = stream;
    } catch (error) {
        videoPlayer.src = URL.createObjectURL(stream);
    }
    videoPlayer.play();
    videoPlayers.push(videoPlayer);
}

function captureDesktop() {
    console.log("enter captureDesktop");

    if (isRecordingVOD) {
        stopVODRecording();

        return;
    }

    if (recorder && recorder.streams) {
        recorder.streams.forEach(function(stream, idx) {
            stream.getTracks().forEach(function(track) {
                track.stop();
            });

            if (idx == 0 && typeof stream.onended === "function") {
                stream.onended();
            }
        });

        recorder.streams = null;

        return;
    }

    chrome.browserAction.setIcon({
        path: "images/main-icon.png"
    });

    if (enableTabCaptureAPI) {
        captureTabUsingTabCapture();

        return;
    }

    var screenSources = ["screen", "window", "audio"];

    if (enableSpeakers === false) {
        screenSources = ["screen", "window"];
    }

    console.log("start captureDesktop");
    chrome.desktopCapture.chooseDesktopMedia(screenSources, onAccessApproved);

    console.log("done captureDesktop");
    chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
        eventPage: "hideSpinner"
    });
}

function onAccessApproved(chromeMediaSourceId, opts) {
    console.log("onAccessApproved");

    if (!chromeMediaSourceId || !chromeMediaSourceId.toString().length) {
        forcedShutdown();

        return;
    }

    var constraints = {
        audio: false,
        video: {
            mandatory: {
                chromeMediaSource: "desktop",
                chromeMediaSourceId: chromeMediaSourceId
            },
            optional: []
        }
    };

    if (videoMaxFrameRates && videoMaxFrameRates.toString().length) {
        videoMaxFrameRates = parseInt(videoMaxFrameRates);

        // 30 fps seems max-limit in Chrome?
        if (videoMaxFrameRates /* && videoMaxFrameRates <= 30 */ ) {
            constraints.video.maxFrameRate = videoMaxFrameRates;
        }
    }

    constraints.video.mandatory.maxWidth = 1280;
    constraints.video.mandatory.maxHeight = 720;
    constraints.video.mandatory.maxFrameRate = 30;

    if (opts.canRequestAudioTrack === true) {
        constraints.audio = {
            mandatory: {
                chromeMediaSource: "desktop",
                chromeMediaSourceId: chromeMediaSourceId,
                echoCancellation: true
            },
            optional: []
        };
    }

    navigator.webkitGetUserMedia(constraints, function(stream) {
        initVideoPlayer(stream);
        gotStream(stream);
    }, function(error) {
        console.log(error);
    });
}

function capture(callback) {
    console.log("capture");

    var supported = navigator.mediaDevices.getSupportedConstraints();
    var constraints = {};

    if (enableMicrophone) {
        constraints.audio = {};

        if (microphoneDevice && microphoneDevice.length) {
            constraints.audio.deviceId = microphoneDevice;
        }

        if (supported.echoCancellation) {
            constraints.audio.echoCancellation = true;
        }
    }

    navigator.mediaDevices
        .getUserMedia(constraints)
            .then(function(stream) {
                initVideoPlayer(stream);
                callback(stream);
            })
            .catch(function(error) {
                chrome.tabs.create({
                    url: "tmpl/camera-mic.html"
                },
                function(tab) {
                  UXC_main_config.tabForCheckMicId = tab.id;
                });

                setDefaults();
            });
}

function audioGainLevelListener(audioStream) {
    context = new AudioContext();

    var source = context.createMediaStreamSource(audioStream),
        analyser = context.createAnalyser(),
        data;

    scriptProcessor = context.createScriptProcessor(2048, 1, 1);
    source.connect(analyser);
    source.connect(scriptProcessor);
    scriptProcessor.connect(context.destination);

    data = new Uint8Array(analyser.frequencyBinCount);

    scriptProcessor.onaudioprocess = function(e) {
        analyser.getByteFrequencyData(data);

        if (!microBroken) {
            if (data[0] < 10 && silenceCounter < 200) {
                silenceCounter++;
            }

            if (data[0] > 10) {
                silenceCounter = 0;

                chrome.runtime.sendMessage({
                    eventPage: "UXC_mic_fixed"
                });

                for (var i in UXC_main_config.arrayTabRec) {
                    chrome.tabs.sendMessage(UXC_main_config.arrayTabRec[i], {
                        eventPage: "UXC_mic_fixed"
                    });
                }
            }

            if (silenceCounter > 100) {
                chrome.runtime.sendMessage({
                    eventPage: "UXC_mic_fail"
                });

                for (var i in UXC_main_config.arrayTabRec) {
                    chrome.tabs.sendMessage(UXC_main_config.arrayTabRec[i], {
                        eventPage: "UXC_mic_fail"
                    });
                }
                //TODO
                //проверка микрофона внутри теста
                /*if (request.eventPage == "check_micro_in_test") {
                    navigator.getUserMedia({
                        audio: true
                    }, function (s) {
                        console.log('микрофон присутствует');
                        chrome.runtime.sendMessage({eventPage: "microOKinTest"});
                    }, function (e) {
                        onMicrophoneCheckError(e);
                        chrome.runtime.sendMessage({eventPage: "microNotOKinTest"});
                    });
                    return;
                }*/
            }
        }
        f(data[0]);
    };
}

function gotStream(stream) {
    globalStream = stream;

    //recorder.pauseRecording();

    chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
        eventPage: "finalModal",
        config: UXC_main_config
    });
}

function getUserConfigs() {
    console.log("getUserConfigs");

    if (enableMicrophone || enableCamera) {
        capture(function(stream) {
            cameraStream = stream;
            captureDesktop();
        });

        return;
    }

    captureDesktop();
}

function getUserMediaError(e) {
    if (!alreadyHadGUMError) {
        // retry with default values
        resolutions = {};
        aspectRatio = false;
        audioBitsPerSecond = false;
        videoBitsPerSecond = false;

        enableTabAudio = false;
        enableMicrophone = false;
        audioStream = false;

        // below line makes sure we retried merely once
        alreadyHadGUMError = true;

        videoMaxFrameRates = "";
        videoCodec = "Default";

        captureDesktop();
        return;
    }

    setDefaults();

    chrome.runtime.reload();
}

function once(fn, context) {
    var result;

    return function() {
        if (fn) {
            result = fn.apply(context || this, arguments);
            fn = null;
        }

        return result;
    };
}

function first_start_and_update() {
    console.log("first_start_and_update");

    chrome.tabs.create({ url: UXC_main_config.url + "/"}, function(tab) {
        var array_page_uxc = [];

        firstStep = true;
        test_tab_id = tab.id;

        chrome.tabs.query({}, function(tab) {
            for (var i in tab) {
                if (tab[i].url.indexOf("localhost") != -1 || tab[i].url.indexOf("192.168.2.121") != -1 || tab[i].url.indexOf("uxcrowd") != -1) {
                    array_page_uxc.push(tab[i].id);
                }
            }

            if (array_page_uxc.length >= 2) {
                for (var i = 0; i < array_page_uxc.length - 1; i++) {
                    chrome.tabs.remove(array_page_uxc[i]); //Закрыли таб с которого писали
                }
            }
        });

        chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
            if (tab.id == test_tab_id) {
                setTimeout(function() {
                    chrome.tabs.sendMessage(test_tab_id, {
                        firstStart: true
                    });

                    localStorage.setItem("UXC_ver", "1");
                }, 1000);
            }
        });
    });
}

function msToTime(s) {
    function addZ(n) {
        return (n < 10 ? "0" : "") + n;
    }

    var ms = s % 1000;
    s = (s - ms) / 1000;
    var secs = s % 60;
    s = (s - secs) / 60;
    var mins = s % 60;
    var hrs = (s - mins) / 60;

    return addZ(hrs) + ":" + addZ(mins) + ":" + addZ(secs) + "." + ms;
}

function setVODRecordingBadgeText(text, title) {
    chrome.browserAction.setBadgeBackgroundColor({
        color: [203, 0, 15, 255]
    });

    chrome.browserAction.setBadgeText({
        text: text
    });
}

function askContentScriptToSendMicrophone(tabId) {
    chrome.tabs.update(tabId, { active: true }, function() {
        var message = {
            giveMeMicrophone: true,
            messageFromContentScript1234: true
        };

        try {
            runtimePort.postMessage(message);
        } catch (e) {
            console.log(e);

            pending.push(message);
        }
    });
}

function createAnswer(sdp) {
    peer = new webkitRTCPeerConnection(null);

    peer.onicecandidate = function(event) {
        if (!event || backPeerInitialized) return;

        if (runtimePort) {
            backPeerInitialized = true;

            console.log("message.sdp--1--");
            console.log("message.sdp--1--", peer.localDescription);

            chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
                sdp: peer.localDescription,
                messageFromContentScript1234: true,
                status: "1"
            });
        } else {
            console.log("error");
        }
    };

    peer.onaddstream = function(event) {
        audioStream = event.stream;
        captureDesktop();
    };

    peer.setRemoteDescription(new RTCSessionDescription(sdp));

    peer.createAnswer(function(sdp) {
        console.log("message.sdp--2--");
        console.log("message.sdp--2--", sdp);

        peer.setLocalDescription(sdp);
    }, function() {}, {
        optional: [],
        mandatory: {
            OfferToReceiveAudio: true,
            OfferToReceiveVideo: false
        }
    });
}
// listeners.js

// ///////////////////////////////////////////////////////////////////////// //
// LISTENERS
// ///////////////////////////////////////////////////////////////////////// //

//
// Application Entry Point
//
chrome.runtime.onMessageExternal.addListener(function(request, sender, sendResponse) {
    console.log("plugin started");

    if (request.eventPage == "setBtn") {
        navigator.getUserMedia(
            { audio: true },
            function(s) {
                microOK();
            },
            function(e) {
                chrome.tabs.create(
                    {
                        url: "tmpl/camera-mic.html"
                    },
                    function(tab) {
                        UXC_main_config.tabForCheckMicId = tab.id;
                    }
                );
                setDefaults();
            }
        );

        userId = request.account.id;

        UXC_main_config.mainUxcTabId = sender.tab.id;
        UXC_main_config.orderId = request.orderId;
        UXC_main_config.statsId = request.statsId;
        UXC_main_config.tester_role = request.account.role;
        UXC_main_config.user.authorization = true;
        UXC_main_config.user.csrf_token = request.xsrfToken;

        update_stats({ screenName: "SCREEN_CAPTURE" });

        return;
    }

    if (request.eventPage == "reload_page") {
        sendResponse({
            reload_page: localStorage.getItem("reload_page")
        });
        localStorage.setItem("reload_page", false);

        return;
    }
});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    var removeTab = function() {
        chrome.tabs.update(request.mainTabId, {
            active: true
        });
        chrome.tabs.remove(Number(request.tabId));
    };

    if (request.eventPage == "openPopupApp" || (sender.tab && UXC_main_config.idTab == sender.tab.id)) {
        if (request.eventPage == "openPopup" || request.eventPage == "openPopupApp") {
            sendResponse({
                config: UXC_main_config
            });

            return;
        }
    }
    //надо чтобы знать где у нас главный таб, чтобы переключится на него и закрыть таб проверки
    if (request.eventPage == "readyForCheckMic") {
        //Надо быть уверенным что таб с проверкой микрофона уже открылся
        function checkIt() {
            if (UXC_main_config.tabForCheckMicId) {
                chrome.tabs.sendMessage(UXC_main_config.tabForCheckMicId, {
                    message: {
                        tabId: UXC_main_config.tabForCheckMicId,
                        mainTabId: UXC_main_config.mainUxcTabId
                    }
                });
            } else {
                setTimeout(checkIt, 500);
            }
        }
        checkIt();

        return;
    }
    if (request.eventPage == "microOK") {
        removeTab();
        microOK();

        return;
    }

    if (request.eventPage == "microNotOK") {
        removeTab();
        microNotOK(request.mainTabId, request.errorName);

        return;
    }

    if (request.eventPage == "microOKinTest") {
        microBroken = false;

        return;
    }

    //функция срабатывает после загрузки любой страницы
    if (request.eventPage == "grabRequirements") {
        console.log(UXC_main_config);
        //если это главная страница и пользователь пытался закрыть её
        if (sender.tab.id === UXC_main_config.mainUxcTabId && UXC_main_config.interrupt) {
            chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
                eventPage: "interrupt"
            });
            return;
            //если это главная страница и у нас есть локальный файл с тестом значит мы готовы его отправить
        } else if (sender.tab.id === UXC_main_config.mainUxcTabId && UXC_main_config.localSaveBlob) {
            chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
                eventPage: "openFinalModal"
            });
            return;
            //если это главная страница и не один из описанных выше случаев и у нас есть taskId, значит либо мы готовы начать тестирование
            //либо уже проходим. В любом случае выводим пользователю страницу с инструкциями и кнопкой "Поехали"
        } else if (sender.tab.id === UXC_main_config.mainUxcTabId && UXC_main_config.taskIdResponse) {
            chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
                eventPage: "finalModal"
            });
            return;
        } else if (UXC_main_config.statusShowRec && ((UXC_main_config.statusRec != "default" && UXC_main_config.statusRec != "audioStartError" && UXC_main_config.statusRec != "rec") || UXC_main_config.statusRec == "selectDesktop")) {
            UXC_main_config.statusRec = "show_requirements";
            sendResponse({
                config: UXC_main_config
            });
        }

        return;
    }

    if (request.eventPage == "microNotOKinTest") {
        microBroken = true;

        for (var i in UXC_main_config.arrayTabRec) {
            chrome.tabs.sendMessage(UXC_main_config.arrayTabRec[i], {
                eventPage: "microNotOKinTest"
            });
        }

        return;
    }

    var updateTabsArray = function() {
        for (var i in UXC_main_config.arrayTabRec) {
            chrome.tabs.sendMessage(UXC_main_config.arrayTabRec[i], {
                eventPage: "update",
                config: UXC_main_config
            });
        }
    };

    if (request.eventPage == "secondStart") {
      update_stats({ screenName: "START_PLUGIN" });
      chrome.tabs.update(UXC_main_config.idTab, {
            active: true
        });

        console.log("gotStream");

        var options = {
            type: "video",
            disableLogs: false,
            recorderType: MediaStreamRecorder // StereoAudioRecorder
        };

        if (!videoCodec) {
            videoCodec = "Default"; // prefer VP9 by default
        }

        if (videoCodec) {
            if (videoCodec === "Default") {
                options.mimeType = "video/webm;codecs=vp9";
            }

            if (videoCodec === "VP8") {
                options.mimeType = "video/webm;codecs=vp8";
            }

            if (videoCodec === "VP9") {
                options.mimeType = "video/webm;codecs=vp9";
            }

            if (videoCodec === "H264") {
                if (isMimeTypeSupported("video/webm;codecs=h264")) {
                    options.mimeType = "video/webm;codecs=h264";
                }
            }

            if (videoCodec === "MKV") {
                if (isMimeTypeSupported("video/x-matroska;codecs=avc1")) {
                    options.mimeType = "video/x-matroska;codecs=avc1";
                }
            }
        }

        if (bitsPerSecond) {
            bitsPerSecond = parseInt(bitsPerSecond);
            if (!bitsPerSecond || bitsPerSecond < 100) {
                bitsPerSecond = 8000000000; // 1 GB /second
            }
        }

        if (bitsPerSecond) {
            options.bitsPerSecond = bitsPerSecond;
        }

        //удаляем все лишние аудио треки
        if (globalStream && globalStream.getAudioTracks().length) {
            globalStream.getAudioTracks().forEach(function(track) {
                globalStream.removeTrack(track);
            });
        }

        if (cameraStream && cameraStream.getAudioTracks().length) {
            audioGainLevelListener(cameraStream);
            cameraStream.getAudioTracks().forEach(function(track) {
                cameraStream.removeTrack(track);
                globalStream.addTrack(track);
            });
        }

        // fix https://github.com/muaz-khan/RecordRTC/issues/281
        options.ignoreMutedMedia = false;

        mimeType = "video/webm;codecs=vp9";
        fileExtension = "webm";
        recorderType = null;
        type = "video";

        var options = {
            type: type,
            mimeType: mimeType,
            disableLogs: false,
            getNativeBlob: false
        };
        options.videoBitsPerSecond = 800000;

        recorder = RecordRTC(globalStream, options);
        recorder.stream = globalStream;

        console.log("startRecording");
        recorder.startRecording();

        recorder.stream.onended = function() {
            console.log("onended");

            if (recorder && recorder.stream.length) {
                recorder.stream.onended = null;
            }

            stopScreenRecording();
        };

        if (recorder.stream.getVideoTracks().length) {
            recorder.stream.getVideoTracks().forEach(function(track) {
                track.onended = function() {
                    if (!recorder) return;

                    var stream = recorder.stream;
                    if (!stream || typeof stream.onended !== "function") return;

                    stream.onended();
                };
            });
        }

        isRecording = true;
        onRecording();

        if (firstStep) {
            setTimeout(function() {
                stopRec();

                chrome.tabs.update(test_tab_id, {
                    active: true
                });
                chrome.tabs.sendMessage(test_tab_id, {
                    firstEnd: true
                });
            }, 1000);
        }

        UXC_main_config.statusRec = "rec";

        var onUpdatedTabs = function() {
            if (UXC_main_config.requirements) {
                if (UXC_main_config.statusShowRec) {
                    if (UXC_main_config.statusRec != "audioStartError") {
                        UXC_main_config.statusRec = "show_requirements";

                        updateTabsArray();
                    }
                } else {
                    updateTabsArray();
                }
            } else {
                updateTabsArray();
            }
        };

        chrome.tabs.onReplaced.addListener(function(newTab, tab) {
            if (UXC_main_config.idTab == tab) {
                UXC_main_config.idTab = newTab;
            }

            for (var i in UXC_main_config.arrayTabRec) {
                if (UXC_main_config.arrayTabRec[i] == tab) {
                    UXC_main_config.arrayTabRec[i] = newTab;

                    setTimeout(function() {
                        chrome.tabs.sendMessage(UXC_main_config.arrayTabRec[i], {
                            eventPage: "update",
                            config: UXC_main_config
                        });
                    }, 1000);
                }
            }
        });

        chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
            if (UXC_main_config.idTab == tabId) {
                UXC_main_config.mainPageUrl = tab.url;
            }

            for (var i in UXC_main_config.arrayTabRec) {
                if (UXC_main_config.arrayTabRec[i] == tab.id) {
                    setTimeout(function() {
                        chrome.tabs.sendMessage(UXC_main_config.arrayTabRec[i], {
                            eventPage: "update",
                            config: UXC_main_config
                        });
                    }, 1000);
                }
            }

            onUpdatedTabs();
        });

        onUpdatedTabs();

        initialTime = Date.now();
        timer = setInterval(checkTime, 100);
        cpuUsageTimer = setInterval(getCPUAndMemoryUsage, 5000);

        return;
    }

    if (request.eventPage == "startRec") {
        if (UXC_main_config.statusRec == "default") {
            UXC_main_config.statusRec = "selectDesktop";

            var sysInfo = new String();

            chrome.system.cpu.getInfo(function(info) {
                var str = "CPU: ";

                sysInfo += str + info.modelName + " (" + info.archName + "architecture" + " - " + info.numOfProcessors + " processors); ";
                var appVersion = navigator.appVersion;

                sysInfo += getOSInfo(appVersion);
                systemInfo.archName = info.archName;
                systemInfo.processorModel = info.modelName;
                systemInfo.numOfProcessors = info.numOfProcessors;
                update_stats({ screenName: "SCREEN_CAPTURE" });
                console.log(sysInfo);
                first_start();
            });

            return;
        }

        return;
    }

    if (request.eventPage == "openCloseTab") {
        chrome.tabs.create({ url: UXC_main_config.mainPageUrl }, function(tab) {
            UXC_main_config.idTab = tab.id;
            UXC_main_config.statusRec = "rec";
            chrome.tabs.update(tab.id, {
                active: true
            }); //Передали фокус главному окну
            stopPause();
            recorder.resumeRecording();
        });

        return;
    }

    if (request.eventPage == "selectTab") {
        captureDesktop();

        return;
    }

    if (request.eventPage == "stopRec") {
        if (UXC_main_config.statusRec != "default") {
            UXC_main_config.statusRec = "default";

            addTimeAndValue(request.answerValue);
            stopRec();

            updateTabsArray();

            chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
                eventPage: "openBeforeFinalModal"
            });

            sendResponse({
                config: UXC_main_config
            });
        }

        return;
    }

    if (request.eventPage == "pauseRec") {
        if (UXC_main_config.statusRec != "pause") {
            UXC_main_config.statusRec = "pause";

            startPause();
            recorder.pauseRecording();

            sendResponse({
                config: UXC_main_config
            });
        }

        return;
    }

    if (request.eventPage == "resumeRec") {
        if (UXC_main_config.statusRec != "rec") {
            UXC_main_config.statusRec = "rec";

            stopPause();
            recorder.resumeRecording();

            sendResponse({
                config: UXC_main_config
            });
        }

        return;
    }

    if (request.eventPage == "firstStart") {
        getUserConfigs();
        return;
    }

    if (request.eventPage == "nextStep") {
        UXC_main_config.activeStep++;
        UXC_main_config.time_click_next = Math.floor(new Date().getTime() / 1000);

        addTimeAndValue(request.answerValue);
        sendResponse({
            config: UXC_main_config
        });

        return;
    }

    if (request.eventPage == "saveAndSendVideo") {
        sendVideo(() => {
            update_stats({ screenName: "UPLOAD_VIDEO", testerTaskId: UXC_main_config.taskIdResponse });
        }, (message) => {
            update_stats({ screenName: "UPLOAD_VIDEO", errorMessage: message });
        },);

        return;
    }

    if (request.eventPage == "breakTest") {
      update_stats({ screenName: "BREAK_TEST", stepNumber: UXC_main_config.activeStep });
      forcedShutdown();
        return;
    }

    if (request.eventPage == "forcedShutdown") {
        forcedShutdown();

        return;
    }

    if (request.eventPage == "reloadApp") {
        location.reload();

        return;
    }

    if (request.eventPage == "reloadAppFirst") {
        location.reload();

        return;
    }

    if (request.eventPage == "autoAndSaveAndSendVideo") {
        authorization_uxc("reloadOfForbidden");

        return;
    }

    if (request.eventPage == "recCloseTab") {
        if (UXC_main_config.arrayTabRec.length > 0) {
            UXC_main_config.statusRec = "rec";
            UXC_main_config.idTab = UXC_main_config.arrayTabRec[UXC_main_config.arrayTabRec.length - 1];

            chrome.tabs.update(UXC_main_config.idTab, {
                active: true
            }); //Передали фокус главному окну

            stopPause();
            recorder.resumeRecording();
        } else {
            chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
                eventPage: "closeAfterTab"
            });
        }

        return;
    }

    if (request.eventPage == "firstEnd") {
        stopScreenRecording(false);
        location.reload();

        return;
    }

    if (request.eventPage == "update_config_popup") {
        console.log("update_config_popup", UXC_main_config);

        sendResponse({
            config: UXC_main_config
        });

        return;
    }

    if (request.eventPage == "update_config_status_rec") {
        console.log("rec");

        UXC_main_config.statusRec = "rec";
        UXC_main_config.statusShowRec = false;
        updateTabsArray();

        return;
    }

    if (request.eventPage == "update_config") {
        UXC_main_config.statusShowRec = false;
        updateTabsArray();

        return;
    }

    if (request.eventPage == "continue_after_interrupt") {
        UXC_main_config.interrupt = false;
        return;
    }

    updateTabsArray();
});

chrome.tabs.onRemoved.addListener(function(tabId, infoClose) {
    //отслеживаем закрытие главного окна; флаг interrupt - флаг состояния закрытия. При первой попытке закрытия выставляется в true
    //если после этого пользователь попытался закрыть вновь открытое окно, то плагин прекращает свою работу
    //но если пользователь нажал продолжить то флаг устанавливается в false
    if (tabId == UXC_main_config.mainUxcTabId && UXC_main_config.taskIdResponse) {
        if (!UXC_main_config.interrupt) {
            UXC_main_config.interrupt = true;
            //при попытке закрыть главную вкладку открываем окно с предупреждением
            chrome.tabs.create({ url: UXC_main_config.url }, function(tab) {
                UXC_main_config.mainUxcTabId = tab.id;
            });
        } else {
            //если это вторая подряд попытка, то заканчиваем тестирование
          update_stats({ screenName: "CLOSE_TAB", stepNumber: UXC_main_config.activeStep });
          forcedShutdown();
        }
    } else {
        for (var i in UXC_main_config.arrayTabRec) {
            if (UXC_main_config.arrayTabRec[i] == tabId) {
                if (UXC_main_config.arrayTabRec[i] == UXC_main_config.idTab) {
                    UXC_main_config.statusRec = "pause";

                    startPause();
                    recorder.pauseRecording();

                    chrome.tabs.sendMessage(UXC_main_config.mainUxcTabId, {
                        eventPage: "closeRecTab",
                        config: UXC_main_config
                    });

                    chrome.tabs.update(UXC_main_config.mainUxcTabId, {
                        active: true
                    }); //Передали фокус главному окну
                }

                UXC_main_config.arrayTabRec.splice(i, 1);
            }
        }
    }
});

chrome.runtime.onInstalled.addListener(function(data) {
    localStorage.setItem("reload_page", true);
});

chrome.management.onEnabled.addListener(function(ExtensionInfo) {
    localStorage.setItem("reload_page", true);
});
